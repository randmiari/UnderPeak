plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.underpeak"
    compileSdk {
        version = release(36)
    }

    defaultConfig {
        applicationId = "com.example.underpeak"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {

    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)

    implementation("com.google.android.material:material:1.11.0")
    implementation("com.github.chrisbanes:PhotoView:2.3.0")




    //I have added
    implementation("com.otaliastudios:zoomlayout:1.9.0")
    // implementation("com.github.barteksc:android-pdf-viewer:3.2.0-beta.1")
    //implementation(libs.core)

    // Replace implementation(libs.core) with:
    implementation("androidx.core:core-ktx:1.12.0")

    //end of what i have added
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
    //FURTHER I HAVE ADDED THIS SHIT
    val cameraxVersion = "1.5.2"

    implementation("androidx.camera:camera-core:$cameraxVersion")
    implementation("androidx.camera:camera-camera2:$cameraxVersion")
    implementation("androidx.camera:camera-lifecycle:$cameraxVersion")
    implementation("androidx.camera:camera-view:$cameraxVersion")
}
