package com.example.underpeak;

import static androidx.core.content.ContentProviderCompat.requireContext;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class ImageTimelineAdapter  extends ArrayAdapter<ImageItemTimeline> {
    private final LayoutInflater inflater;
    private final List<ImageItemTimeline> items;
    private long startTime;

    public ImageTimelineAdapter(Context context, List<ImageItemTimeline> items, long startTime) {
        super(context, 0, items);
        this.inflater = LayoutInflater.from(context);
        this.items = items;
        this.startTime = startTime;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;


        if (convertView == null) {
            convertView = inflater.inflate(R.layout.activity_image_item_timeline, parent, false);
            holder = new ViewHolder();
            holder.imageView = convertView.findViewById(R.id.ImageID);
            holder.headView = convertView.findViewById(R.id.ListHeadID);
            holder.bodyView = convertView.findViewById(R.id.ListBodyID);
            convertView.setTag(holder);
        }
        else {
            holder = (ViewHolder) convertView.getTag();
        }

        ImageItemTimeline item = items.get(position);
        holder.imageView.setImageURI(Uri.parse(item.imageUri));
        holder.headView.setText(item.head);
        holder.bodyView.setText(item.body);

        /// OPENing up the Image in ImageDetailZOOMABLEActivity once u click on it
        holder.imageView.setOnClickListener(v -> {
            Intent intent = new Intent(getContext(), ImageDetailZOOMABLEActivity.class);
            intent.putExtra(ImageDetailZOOMABLEActivity.detail_image, item.imageUri);
            getContext().startActivity(intent);

        }); ///END

//        /// EDITING THE BODY
//        holder.bodyView.setOnClickListener(v -> {
//            if(startTime != -1) {
//                EditText editText = new EditText(getContext());
//                editText.setText(item.body);
//
//                new AlertDialog.Builder(getContext())
//                        .setTitle("Edit Description")
//                        .setView(editText)
//                        .setPositiveButton("Save", (dialog, which) -> {
//                            //new text
//                            item.body = editText.getText().toString();
//                            //reregister Adapter
//                            notifyDataSetChanged();
//                        })
//                        .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
//                        .show();
//            } else editingAlert();
//            }); ///END
//
//        /// EDITING THE HEAD
//        holder.headView.setOnClickListener(v -> {
//            if (startTime != -1) {
//
//
//                EditText editText = new EditText(getContext());
//                editText.setText(item.head); // aktuellen Text vorbelegen
//
//                new AlertDialog.Builder(getContext())
//                        .setTitle("Edit Headline")
//                        .setView(editText)
//                        .setPositiveButton("Save", (dialog, which) -> {
//
//                            item.head = editText.getText().toString();
//
//                            notifyDataSetChanged();
//                        })
//                        .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
//                        .show();
//            } else editingAlert();
//        }); ///END

        ///  Both at once in a new .xml as my AlertDialog!
        convertView.setOnClickListener(v -> {
            if (startTime != -1) {

                View dialogView = LayoutInflater.from(getContext())
                        .inflate(R.layout.dialog_edit_item, null);

                EditText editHead = dialogView.findViewById(R.id.editHead);
                EditText editBody = dialogView.findViewById(R.id.editBody);

                //the old text again
                editHead.setText(item.head);
                editBody.setText(item.body);

                new AlertDialog.Builder(getContext(), R.style.myTheme)
                        .setTitle("Edit Item")
                        .setView(dialogView)
                        .setPositiveButton("Save", (dialog, which) -> {
                            item.head = editHead.getText().toString();
                            item.body = editBody.getText().toString();
                            notifyDataSetChanged();
                        })
                        .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                        .show();

            } else {
                editingAlert(); //this is in case the tour is not finished yet - we dont want people to spend time inside the cave on their phone too much
            }
        });


        /// CLICK LOOONG to delete a "NOTE"
        convertView.setOnLongClickListener(v -> {
            if (startTime != -1) {
                new AlertDialog.Builder(getContext(), R.style.myTheme)
                        .setTitle("Do you really want to delete this timeline entry?")
                        .setMessage("Note: this will not delete any photos from your gallery")
                        .setPositiveButton("Yes", (dialog, which) -> {
                            items.remove(position);
                            notifyDataSetChanged();
                            dialog.dismiss();
                        })
                        .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                        .show();
            }else editingAlert();
            return true;
        }); ///END



        return convertView;
    }

    private static class ViewHolder {
        ImageView imageView;
        TextView headView;
        TextView bodyView;
    }

    private void editingAlert() {
        AlertDialog dialog = new AlertDialog.Builder(getContext(), R.style.myTheme)
                .setTitle("Sorry, editing not yet possible")
                .setMessage("Please stay focussed on your journey. Editing will be possible after you have finished your cave-tour")
                .setPositiveButton("Okay", (d, which) -> d.dismiss())
                .create();
        dialog.show();
    }

}

