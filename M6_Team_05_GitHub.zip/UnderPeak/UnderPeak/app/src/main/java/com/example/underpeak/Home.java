package com.example.underpeak;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.AppBarLayout;
import java.util.ArrayList;

public class Home extends Fragment {

    private RecyclerView recyclerView;
    private CustomAdapter customAdapter;
    private ArrayList<CustomModel> fullCaveList;
    private EditText etSearch;
    private View searchContainer;
    private AppBarLayout appBarLayout;

    public Home() {}

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // 1. Setup UI Components
        etSearch = view.findViewById(R.id.etSearch);
        searchContainer = view.findViewById(R.id.searchContainer);
        appBarLayout = view.findViewById(R.id.appBarLayout);
        recyclerView = view.findViewById(R.id.recyclerView);
        Button btnExplore = view.findViewById(R.id.btnExplore);

        // 2. Load Data from AppData
        fullCaveList = AppData.getAllCaves();

        // 3. Initialize RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        customAdapter = new CustomAdapter(requireContext(), new ArrayList<>(fullCaveList));
        recyclerView.setAdapter(customAdapter);

        // 4. Navigation
        btnExplore.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), ExploreCavesActivity.class));
        });

        // 5. Sticky Search Shadow Logic
        if (appBarLayout != null && searchContainer != null) {
            appBarLayout.addOnOffsetChangedListener((layout, verticalOffset) -> {
                float elevation = (Math.abs(verticalOffset) >= layout.getTotalScrollRange()) ? 12f : 0f;
                searchContainer.setElevation(elevation);
            });
        }

        // 6. Real-time Search Filter
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filter(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        return view;
    }

    private void filter(String text) {
        String query = text.toLowerCase().trim();
        ArrayList<CustomModel> filteredList = new ArrayList<>();

        if (query.isEmpty()) {
            filteredList.addAll(fullCaveList);
        } else {
            for (CustomModel item : fullCaveList) {
                if (item.getTitle().toLowerCase().contains(query) ||
                        item.getLocation().toLowerCase().contains(query)) {
                    filteredList.add(item);
                }
            }
        }
        customAdapter.updateList(filteredList);
    }
}