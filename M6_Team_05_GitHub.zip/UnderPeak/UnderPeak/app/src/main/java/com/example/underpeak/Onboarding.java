package com.example.underpeak;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

public class Onboarding extends AppCompatActivity {

    private ViewPager2 viewPager;
    private Button btnStart, btnSkip;

    private final String[] titles = {
            "Explore Nearby Caves",
            "Track Your Cave Walk",
            "Smart Timer & Emergency Alarm"
    };

    private final String[] descriptions = {
            "Here you can explore the caves near you and discover amazing places around you.",
            "Track your walk inside the cave and familiarise yourself with important checkpoints along the way.",
            "A smart timer adapts to your walking speed and calculates the right time for your exit. It also includes an emergency alarm for safety."
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. Check if user has already seen onboarding
        SharedPreferences preferences = getSharedPreferences("PREFERENCE", MODE_PRIVATE);
        boolean isFirstRun = preferences.getBoolean("isFirstRun", true);

        if (!isFirstRun) {
            // Skip directly to MainActivity
            goToMain();
            return;
        }

        // 2. Load the correct Onboarding layout
        setContentView(R.layout.activity_onboarding);

        // 3. Initialize UI elements
        viewPager = findViewById(R.id.viewPager);
        btnStart = findViewById(R.id.btnStart);
        btnSkip = findViewById(R.id.btnSkip);

        // 4. Setup Adapter
        final OnboardingAdapter adapter = new OnboardingAdapter(titles, descriptions);
        viewPager.setAdapter(adapter);

        // 5. Page Change Logic
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                // Update internal adapter state (like dots/indicators)
                adapter.setCurrentPage(position);

                // Show "Start" button only on the final page
                if (position == titles.length - 1) {
                    btnStart.setVisibility(View.VISIBLE);
                    btnSkip.setVisibility(View.GONE);
                } else {
                    btnStart.setVisibility(View.GONE);
                    btnSkip.setVisibility(View.VISIBLE);
                }
            }
        });

        // 6. Skip Button -> Jump to the last page
        btnSkip.setOnClickListener(v ->
                viewPager.setCurrentItem(titles.length - 1, true)
        );

        // 7. Start Button -> Save preference and move to MainActivity
        btnStart.setOnClickListener(v -> {
            // Save the flag so this screen never shows again
            preferences.edit().putBoolean("isFirstRun", false).apply();
            goToMain();
        });
    }

    /**
     * Helper method to handle the transition to the main part of the app.
     */
    private void goToMain() {
        Intent intent = new Intent(Onboarding.this, MainActivity.class);
        startActivity(intent);
        finish(); // Remove Onboarding from the backstack
    }
}