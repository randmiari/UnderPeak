package com.example.underpeak;



import static androidx.core.content.ContextCompat.registerReceiver;
import static java.lang.Math.sqrt;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;


import androidx.fragment.app.Fragment;

import android.os.CountDownTimer;
import android.os.Handler;
import android.os.PowerManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;


public class TimerFragment extends Fragment {

        private TextView returnTimerText;
        private Button timerButton;
        private Button ButtonOpenCamera;
        private Button ButtonReached;
        private CountDownTimer returnTimer;
        private CountDownTimer caveTimer;
        private TextView caveTimerText;
        private TextView minInfo; ///its just for the "minutes left" next to the timer...
        private TextView explorationInfo; ///Just for "of exploring"
        private TextView returnMessage; ///Just for the "PLEASE RETURN!"

        private CountDownTimer cameraTimer;
        private int secondsCounterCamera = 0;
        private int secondsCounterSensors = 0;


        private Ringtone alarmRingtone;
        private int numberOfTimersStartedCamera = 1; ///MAY NOT BE NECESSARY ANYMORE, was rather nice for my toasts
        private boolean cameBackFromCamera = false;
    //    private boolean adaptingTimerEnabled = false; ///MAY NOT BE NECESSARY

        private long wastedTimeInCamera = 0;
        private boolean returnIniciated = false;

        /// Checkpoint Stuff
        private String checkpointCode = "0";
        private String goingToCheckpointCode = "0";
        private String previousCheckpointCode = "0";
        private String recoveryCheckpointCode = "0";
        private Boolean skippedCheckpoint = false;
        private Boolean forgotToStartCheckpoint = false;
        private Boolean REACHED_CHECKPOINT = false;

        /// THE Timer-Bar
        View bufferBar;
        View normalBar;
        View returnBar;
        View overBar;
        LinearLayout timeBar;



        /// Sensors and SensorData
        private SensorManager sensorManager;
        private Sensor accelerometer;
        private Sensor gravitySensor;
        private Sensor pressureSensor;

    float maxVerticalThisSecond = 0f; ///gets me the maximum peak of each second!
    float minVerticalThisSecond = 0f; ///gets me the maximum NEGATIVE Acceleration peak of each second!

    private float ax;
        private float ay;
        private float az;
        private float gx;
        private float gy;
        private float gz;
    private float lastAx = 0;
    private float lastAy = 0;
    private float lastAz = 0;

        private int UP = 0;
        private int DOWN = 0;
        private float MotionUP = 0;
        private float MotionDOWN = 0;
        private boolean screenOn = true;

    private Handler handler = new Handler();
    private Runnable checkRunnable;



    private int crawlingCount = 0;


        /// Time Stuff
    private long currentTimeLeftRETURNTimer = Long.MAX_VALUE;
    private long currentTimeLeftCAVETimer = Long.MAX_VALUE;
    private long startTime;

    private long maxTimeInCave = (long) (1000 *60* 5); //max time inside the cave
    private long millisReturnTimer = (long) (maxTimeInCave *0.75);
    private long timeEntranceTOwooden;
    private long timeGoingBACK;
    ///
    private long pufferTime = (long) (0.25* maxTimeInCave); //minTime for the return

    private long timeSpentBetweenCheckpoints = 0;
    private long timeStartGoingToCheckpoint = 0; //Here i save the time when u click on the "head to checkpoint button"
    private long timeNeededToLeave = 0;
    private boolean ended;





    @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {


            View view = inflater.inflate(R.layout.fragment_timer, container, false);


            /// Timer init & Button init
            returnTimerText = view.findViewById(R.id.timer_textID);
            timerButton = view.findViewById(R.id.timer_buttonID);
            caveTimerText = view.findViewById(R.id.timer2ID);
            ButtonReached = view.findViewById(R.id.checkpointReached_buttonID);
            ButtonReached.setVisibility(View.GONE);
            ButtonOpenCamera = view.findViewById(R.id.openCamera_buttonID);
            minInfo = view.findViewById(R.id.minInfoID);
            explorationInfo = view.findViewById(R.id.exploringInfoID);
            returnMessage = view.findViewById(R.id.returnMessageID);

            ///  TimerBar init
        timeBar = view.findViewById(R.id.timeBar);

        bufferBar = view.findViewById(R.id.barBuffer);
        normalBar = view.findViewById(R.id.barNormal);
        returnBar = view.findViewById(R.id.barReturn);
        overBar = view.findViewById(R.id.barOver);

            /// Sensor init.
        sensorManager = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gravitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
        //pressureSensor = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE);


        /// SET TIME WHEN U  CLICK ON THE GREEN TIMEEEEEEEEEEEEEEE
        returnTimerText.setOnClickListener(v -> {

                if(timerButton.getVisibility() == View.VISIBLE) {


                    View dialogView = LayoutInflater.from(requireContext())
                            .inflate(R.layout.dialog_edit_time, null); // wir legen gleich das Layout an

                    NumberPicker hourPicker = dialogView.findViewById(R.id.hourPickerID);
                    NumberPicker minutePicker = dialogView.findViewById(R.id.minutePickerID);
                    NumberPicker secondsPicker = dialogView.findViewById(R.id.secondsPickerID);
                    TextView overallTime = dialogView.findViewById(R.id.OverallTimeID);

                    hourPicker.setMinValue(0);
                    hourPicker.setMaxValue(10);
                    minutePicker.setMinValue(0);
                    minutePicker.setMaxValue(59);
                    secondsPicker.setMinValue(0);
                    secondsPicker.setMaxValue(59);

                    String[] parts = returnTimerText.getText().toString().split(":");
                    int hours;
                    int minutes = Integer.parseInt(parts[0]);
                    int seconds = Integer.parseInt(parts[1]);

                    if(minutes > 59) {
                        hours = (int) (minutes/60f);
                        minutes = minutes%60;
                        hourPicker.setValue(hours);
                    }
                    minutePicker.setValue(minutes);
                    secondsPicker.setValue(seconds);

                    ///SINCE THIS WAS RATHER A "NICE TO HAVE" AND I AM RUNNING out of time i just added this by ChatGPT since i got confused how to use the runnable since its supposed to be real-time
                    Runnable updateTime = () -> {
                        long h = hourPicker.getValue();
                        long m = minutePicker.getValue();
                        long s = secondsPicker.getValue();

                        long totalMillis = (h * 3600 + m * 60 + s) * 1000;

                        long maxTimeInCave = (long) (totalMillis * 1.3333333333333333);
                        int sec_max = (int) ((maxTimeInCave/1000) % 60);
                        int min_max  = (int) ((maxTimeInCave/1000/60)%60);
                        int h_max = (int) (maxTimeInCave/1000/60/60);

                        overallTime.setText("Overall Time: " + h_max + ":" + String.format("%02d:%02d", min_max, sec_max));

                        //pufferTime = (long) (maxTimeInCave * 0.25);
                    };

                    NumberPicker.OnValueChangeListener listener =
                            (picker, oldVal, newVal) -> updateTime.run();

                    hourPicker.setOnValueChangedListener(listener);
                    minutePicker.setOnValueChangedListener(listener);
                    secondsPicker.setOnValueChangedListener(listener);

                    updateTime.run(); ///END ChatGPT

                    new AlertDialog.Builder(requireContext(), R.style.myTheme)
                            .setTitle("Set Timer")
                            .setMessage("The buffer time will be calculated automatically (25% buffer, 75% your selected time). ")
                            .setView(dialogView)
                            .setPositiveButton("Save", (dialog, which) -> {
                                long h = hourPicker.getValue();
                                long min = minutePicker.getValue();
                                long secs = secondsPicker.getValue();

                                // update my textView
                                long hourMinutes = h * 60 + min;
                                if(hourMinutes > 74) {returnTimerText.setTextSize(34); caveTimerText.setTextSize(13);}
                                else if(hourMinutes > 6) caveTimerText.setTextSize(20);

                                returnTimerText.setText(hourMinutes + ":" + String.format("%02d", secs));  //Seems to be the easy version of making difference between 1:02 and 1:2...
                                long inMillis = hourMinutes * 60 * 1000 + secs * 1000;

                                // my newly added time
                                millisReturnTimer = inMillis;
                                maxTimeInCave = (long) (millisReturnTimer * 1.333333333333333333333333333333333f);

                                /// AFTER DOING THIS LIKE 10 times already i might have just made a Method.... but well... that would be efficient... we dont do that here
                                int min_max  = (int) ((maxTimeInCave/1000/60));
                                caveTimerText.setText(Integer.toString(min_max));

                                pufferTime = (long) (maxTimeInCave*.25);
                            })
                            .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                            .show();
                }
        });





        ///CATCHING WHICH CHECKPOINT THE USER WANTS TO GO TO!!!
        getParentFragmentManager()
                .setFragmentResultListener(
                        "setFlag",
                        getViewLifecycleOwner(),
                        (key, result) -> {

///FIXED THIS SO MUCH EASIER IN THE LAST WEEK OF WORKING ON THIS PROJECT...................
//                            if(View.VISIBLE == timerButton.getVisibility()) { /// MAKING SURE THE TIMER IS ACTIVATED
//                                //Toast.makeText(getContext(), "shitttt", Toast.LENGTH_SHORT).show();
//                                forgotToStartCheckpoint = true;
//                                ButtonReached.setVisibility(View.INVISIBLE);
//                                AlertDialog dialog = new AlertDialog.Builder(requireContext(), R.style.myTheme)
//                                        .setTitle("Please start the cave timer first")
//                                        .setMessage("Then you can start visiting the checkpoints")
//                                        .setPositiveButton("Okay", (d, which) -> d.dismiss())
//                                        .create();
//                                dialog.show();
//                                /// IF THE TIMER WAS DEACTIVATED THE WHOLE TIME I WANT TO RE-OPEN THE WOODENBRIDGE CHECKPOINT
//                                CheckpointFragment checkpointFragment = CheckpointFragment.newInstance(
//                                        "Checkpoint: Wooden Bridge",
//                                        "This is the first step inside the cave.",
//                                        R.drawable.checkpointbruecke
//                                );
//
//                                requireActivity().getSupportFragmentManager()
//                                        .beginTransaction()
//                                        .replace(R.id.fragment_checkpointTextID, checkpointFragment)
//                                        .addToBackStack(null)
//                                        .commit();
//
//                            } else { /// THE NORMAL PROCEDURE: Timer is going and the "is reached button opens up (if checkpoint reachable & if no other checkpoint is already submitted)
                                if (View.INVISIBLE == ButtonReached.getVisibility() || View.GONE == ButtonReached.getVisibility()) { /// No other checkpoint is yet submitted

                                    recoveryCheckpointCode = goingToCheckpointCode; //Saving in order it has not been allowed so that i can redo stuff in SkippedCheckpoint();
                                    goingToCheckpointCode = result.getString("flag"); //Necessary for the whatCheckpointAndTimeAdaptation() to work;
                                    boolean allowed = whatCheckpointAndTimeAdaptation(); //Tells me if i have the right checkpoint-order
                                    if (allowed) {

                                        ButtonReached.setText("I have reached " + goingToCheckpointCode); //If it was allowed then a new buttonReached appears
                                        ButtonReached.setVisibility(View.VISIBLE);
                                        ///Making sure only the time spent in camera between checkpoints is going into the Adaptation of my timer!
                                        wastedTimeInCamera = 0;
                                        secondsCounterCamera = 0;
                                        UP = 0;
                                        DOWN =0;
                                        crawlingCount = 0;
                                        ((CavingActivity) requireActivity()).setHeadToInitiated();

                                        //Toast.makeText(getContext(), "You can start your hike to your chosen " + goingToCheckpointCode, Toast.LENGTH_SHORT).show();
                                        timeStartGoingToCheckpoint = currentTimeLeftRETURNTimer;

                                    }
                                } else  {
                                    twiceTheSameCheckpoint();
                                    //Toast.makeText(getContext(), "ERROR: First you should arrive at the checkpoint you have already submitted:" + previousCheckpointCode, Toast.LENGTH_SHORT).show();
                                }

                        }
                );

        /// MAKING END CAVE TOUR POSSIBLE!!!!
            checkRunnable = new Runnable() {
                @Override
                public void run() {
                    if (((CavingActivity) requireActivity()).getEnded()) {

                        ended = true;

                        if (caveTimer != null) {
                            caveTimer.cancel();
                        }
                        if (returnTimer != null) {
                            returnTimer.cancel();
                        }
                        if (cameraTimer != null) {
                            cameraTimer.cancel();
                        }

                     //   ((CavingActivity) requireActivity()).setEnded(false);

                    } else handler.postDelayed(this, 500);
                }
            };

            handler.post(checkRunnable); ///END



        /// Clicking on the Reached-Button!!! ACTIVATES THE ADAPTATION OF THE TIMER!!!!
        ButtonReached.setOnClickListener(v -> {
            ButtonReached.setVisibility(View.GONE);
            REACHED_CHECKPOINT = true;
            //adaptingTimerEnabled = true;
        });




/// BUTTON FOR STARTING THE TIMERS
        timerButton.setOnClickListener(v -> {
            ((CavingActivity) requireActivity()).setHeadToInitiated();
                timerButton.setVisibility(View.GONE);
                caveTimerText.setVisibility(View.VISIBLE);


            /// Just telling the CaveActivity that we started the Timer.
            if (caveTimer != null) {
                caveTimer.cancel();
            }

            startTime = System.currentTimeMillis();
            Bundle bundle = new Bundle();
            bundle.putLong("startTime", startTime);
            getParentFragmentManager().setFragmentResult("setFlagTime", bundle);
            /// End of telling the CaveActivity that we started the Timer



                caveTimer = new CountDownTimer(maxTimeInCave, 1000) {

                    @Override
                    public void onFinish() {

                        new AlertDialog.Builder(requireContext(), R.style.myTheme)
                                .setTitle("THIS TOUR HAS ENDED")
                                .setMessage("We hope you had a great time and no emergency call was declared, since the deadline has been reached.")
                                .setPositiveButton("Okay", (dialog1, which) -> {
                                    Intent intent = new Intent(requireContext(), JourneyOverviewActivity.class);
                                    intent.putExtra("START_TIME", startTime); //Sending the start_time to the other activity
                                    startActivity(intent);
                                })
                                .show();
                    }

                    @Override
                    public void onTick(long millisUntilFinished) {
                        currentTimeLeftCAVETimer = millisUntilFinished;
                        updateTimeBar(currentTimeLeftCAVETimer);
                        long minutes = millisUntilFinished / 1000 / 60;
                        long seconds = (millisUntilFinished / 1000) % 60;

                        if(10<minutes && minutes<100) {returnTimerText.setTextSize(45); caveTimerText.setTextSize(20); minInfo.setTextSize(13);}
                        else if(minutes <=9) caveTimerText.setTextSize(32);///THIS IS IN CASE THE TIME WAS SO LARGE THAT IT WOULDN'T FIT FULLSIZE AND TIME GONE BY IT GOT SMALLER AGAIN

                        if(returnIniciated) {
                            minInfo.setVisibility(View.GONE);
                            explorationInfo.setVisibility(View.GONE);
                            caveTimerText.setVisibility(View.GONE);
                            returnMessage.setVisibility(View.VISIBLE);

                            if (currentTimeLeftCAVETimer > pufferTime) {
                                returnTimerText.setTextColor(Color.parseColor("#FCE166"));
                                returnMessage.setTextColor(Color.parseColor("#FCE166"));

                            }
                            else {
                                returnTimerText.setTextColor(Color.parseColor("#E53935"));
                                returnMessage.setTextColor(Color.parseColor("#E53935"));

                                if(currentTimeLeftCAVETimer < pufferTime*0.5 && seconds%2 == 0) returnTimerText.setTextColor(Color.parseColor("#FFFFFF"));
                            }
                            if (seconds < 10) returnTimerText.setText(minutes + ":0" + seconds);
                            else returnTimerText.setText(minutes + ":" + seconds);
                        } else {
                            caveTimerText.setText(minutes + "");
                        }
                        /// MAKING SURE THE TIMER END WHEN U CLICK ON ENDING THIS TOUR!!!!

                    }
                }.start();

                adaptiveReturnTimer();
            /// After initiating the timer open the FIRST CHECKPOINT!!!!
            CheckpointFragment checkpointFragment = CheckpointFragment.newInstance(
                    "Checkpoint: Wooden Bridge",
                    "This is the first step inside the cave.",
                    R.drawable.checkpointbruecke
            );

            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_checkpointTextID, checkpointFragment)
                    .addToBackStack(null)
                    .commit();

            });


            ///Opening up the Camera
            ButtonOpenCamera.setOnClickListener(v -> {

/// //////////////////////////////////////////777777777777777777777777777
                long CountdownTimeInCamera = Long.MAX_VALUE;
                if (cameraTimer != null) {
                    cameraTimer.cancel();
                    numberOfTimersStartedCamera++;

                }

                int finalNumberOfTimersStartedCamera = numberOfTimersStartedCamera;

                cameraTimer = new CountDownTimer(CountdownTimeInCamera, 1000) {
                    @Override
                    public void onFinish() {
                        Toast.makeText(getContext(), "What the fuck?!", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onTick(long millisUntilFinished) {
                        secondsCounterCamera++;

                        if (secondsCounterCamera % (60*10) == 0 && secondsCounterCamera != 0) {
                            Toast.makeText(getContext(), "Don't waste time. Ten minutes have gone by inside the camera...", Toast.LENGTH_SHORT).show();

                        }
                    }
                };

                cameraTimer.start();
/// //////////////////////////////////7777777777777777777777777777
                cameBackFromCamera = true;
                Intent intent = new Intent(requireContext(), CameraActivity.class);
                intent.putExtra("CHECKPOINT", previousCheckpointCode);
                startActivity(intent);

         });

            return view;
        }




    /// HERE IS THE STUFF REGARDING THE SENSORS!!!
    private final SensorEventListener sensorListener = new SensorEventListener() {

        @Override
        public void onSensorChanged(SensorEvent event) {

            if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                ax = event.values[0];
                ay = event.values[1];
                az = event.values[2];

                // Bewegung
            }

            if (event.sensor.getType() == Sensor.TYPE_GRAVITY) {
                gx = event.values[0];
                gy = event.values[1];
                gz = event.values[2];

                // Lage (liegen / aufrecht)
            }

            /// /////////////MAKE NEW METHOD for this LATER!
            float gBetrag = (float) sqrt(gx*gx + gy*gy + gz*gz);
            float AccVertikal = (ax*gx + ay*gy + az*gz) / gBetrag;
            float verticalMotion = AccVertikal - gBetrag;

            // my positive Peaks: UP
            if (verticalMotion > maxVerticalThisSecond) {
                maxVerticalThisSecond = verticalMotion;
            }

            // my negative Peaks: DOWN
            if (verticalMotion < minVerticalThisSecond) {
                minVerticalThisSecond = verticalMotion;
            }


            //  if (event.sensor.getType() == Sensor.TYPE_PRESSURE) {
            //    float pressure = event.values[0];

            //    float altitude = SensorManager.getAltitude(
            //            SensorManager.PRESSURE_STANDARD_ATMOSPHERE,
            //            pressure
            //    );


           // }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {}
    };






    ///ADAPTATION OF THE TIMER HAPPENS HERE
    private void adaptiveReturnTimer() {
        if (returnTimer != null) {
            returnTimer.cancel();
        }


//        if(currentTimeLeftRETURNTimer != Long.MAX_VALUE) { //Timer has to be activated for this to work
//
//            timeSpentBetweenCheckpoints = millisReturnTimer - currentTimeLeftRETURNTimer;
//            Toast.makeText(getContext(), "Time spent between Checkpoints: " + (long) (timeSpentBetweenCheckpoints /1000) + "s", Toast.LENGTH_SHORT).show();
//            /// /'''''''''''''''''Q'Q'QCIWCNQEVBUFHFH MAKE SOMETHING WITH THIS!!!!!
//            millisReturnTimer = currentTimeLeftRETURNTimer + (long) (wastedTimeInCamera * 1000 * 1.0); ///The 70% of the seconds(=*1000) spent in Camera are added to the ReturnTimer
//
//        }
        wastedTimeInCamera = 0;
        secondsCounterCamera = 0;
        /// After initiating the ADAPTATION this tells u to SELECT the next CHECKPOINT
        CheckpointFragment checkpointFragment = CheckpointFragment.newInstance(
                "Congratulations on reaching " + previousCheckpointCode,
                "Take your time to check out every corner - after that you can select a new checkpoint to explore",
                R.drawable.checkpointicon_message
        );

        requireActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_checkpointTextID, checkpointFragment)
                .addToBackStack(null)
                .commit();
//        REACHED_CHECKPOINT = false;
//        checkpointCode = "0";


        returnTimer = new CountDownTimer(millisReturnTimer, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                currentTimeLeftRETURNTimer = millisUntilFinished;
                long minutes = millisUntilFinished / 1000 / 60;
                long seconds = (millisUntilFinished / 1000) % 60;
                if (seconds < 10) returnTimerText.setText(minutes + ":0" + seconds);
                else returnTimerText.setText(minutes + ":" + seconds);

                secondsCounterSensors++;


                /// /////////////MAKE NEW METHOD LATER!
                float gBetrag = (float) sqrt(gx*gx + gy*gy + gz*gz);
                float AccVertikal = (ax*gx + ay*gy + az*gz) / gBetrag;
                float verticalMotion = AccVertikal - gBetrag;

                //float nx = gx / gBetrag;
                float neigungY = gy / gBetrag;
                //float nz = gz / gBetrag;

                /// Here are the "KEEPING STILL" / "NOT MOVING" parameters!!!
                float deltaX = Math.abs(ax - lastAx);
                float deltaY = Math.abs(ay - lastAy);
                float deltaZ = Math.abs(az - lastAz);

                float movement = deltaX + deltaY + deltaZ;

                PowerManager pm = (PowerManager) requireContext().getSystemService(Context.POWER_SERVICE);
                screenOn = pm.isInteractive();


                /// CRAVLING
                if (Math.abs(neigungY) < 0.45f && movement > 2.5f && !screenOn) {
                    crawlingCount = crawlingCount + 2; //plus two because while crawling the if(clause) is not triggered every second rather every two or three seconds

                }

                /// DIFFICULT TERRAIN
//                if(verticalMotion > 0.5f  ) { //1 since Going up is less sensitive then going down - there is more excelleration in stepping onto the ground then in lifting your foot!
//                    UP++;
//                  //  MotionUP = MotionUP + verticalMotion;
//                } else if (verticalMotion < -1.5f  ) { //&&!screenOn   for UP: && verticalMotion < 3.0f
//                    DOWN++;
//                   // MotionDOWN = MotionDOWN - verticalMotion;
//                }

                if (minVerticalThisSecond < -1.5f && !screenOn) {
                    DOWN++;
                }
                else if (maxVerticalThisSecond > 0.5f && maxVerticalThisSecond < 3.0f && !screenOn) {
                    UP++;
                }
                maxVerticalThisSecond = 0f;
                minVerticalThisSecond = 0f;


                lastAx = ax;
                lastAy = ay;
                lastAz = az;







                ///HERE comes the ADAPTATION OF THE TIMER!!! And if the CaveTimer is able to adapt or if it has reached it's minimum time for return!!!
                if(!returnIniciated && REACHED_CHECKPOINT == true) {
                    REACHED_CHECKPOINT = false;
                    ((CavingActivity) requireActivity()).setHeadToInitiated();
                    adaptingTime();
                    adaptiveReturnTimer();
                }
            }

            @Override
            public void onFinish() {
                returnIniciated = true;
                ((CavingActivity) requireActivity()).setReturnInitiated();

                CheckpointFragment checkpointFragment = CheckpointFragment.newInstance(
                        "Head to the entrance",
                        "Your exploration time is over - the remaining time should be used for a save and not rushed return to the entrance",
                        R.drawable.caveentrance
                );

                requireActivity().getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_checkpointTextID, checkpointFragment)
                        .addToBackStack(null)
                        .commit();

                NotificationCompat.Builder builder = new NotificationCompat.Builder(requireContext(), "channel_ID2");
                builder.setContentTitle("WARNING");
                builder.setContentText("You should start your return now!");
                builder.setSmallIcon(R.drawable.checkpointicon_message);
                // builder.setAutoCancel(true);
                builder.setPriority(NotificationCompat.PRIORITY_HIGH);

                //MediaPlayer mediaPlayer = MediaPlayer.create(context, R.raw.sound_file_1);
                //mediaPlayer.start(); // no need to call prepare(); create() does that for you

                NotificationManagerCompat manager =
                        NotificationManagerCompat.from(requireContext());
                if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.

                    /// I AM NOT SURE WHY THIS IS NECESSARY HERE - I THOUGHT I HAVE ARLEADY DONE IT EADLIER!!!!!
                    return;
                }
                manager.notify(1, builder.build());


                //THis is the POP-UP Window that tells its time to go back
                AlertDialog dialog = new AlertDialog.Builder(requireContext(), R.style.myTheme)
                        .setTitle("WARNING")
                        .setMessage("You should start your return now!")
                        .setPositiveButton("Okay", (d, which) -> d.dismiss())
                        .create();

                ///NEWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW SOUND-ALARM ___FOR NOW ITS NOT IN THERE ANYMORE!

//                Uri alarmUri = Uri.parse("android.resource://" + requireContext().getPackageName() + "/" + R.raw.ringtone_public_domain_non_pd_us);
//                alarmRingtone = RingtoneManager.getRingtone(requireContext(), alarmUri);
//                alarmRingtone.play();

                dialog.show();
            }
        }.start();
    }

//
//    @Override
//    public void handleOnBackPressed() {
//        new AlertDialog.Builder(getContext())
//                .setTitle("Leave tour?")
//                .setMessage("Do you really want to exit?")
//                .setPositiveButton("Yes", (d, w) -> finish())
//                .setNegativeButton("No", null)
//                .show();
//    }



    /// ONCE YOU RETURN TO FROM THE CAMERA THE TIMER IS KILLED AND THE SECONDS INSIDE THE CAMERA ARE "WRITTEN DOWN"
    public void onResume() {
        super.onResume();

        if (cameBackFromCamera == true) {  //
            cameBackFromCamera = false;
           // Toast.makeText(getContext(), "Welcome back from the Camera!", Toast.LENGTH_SHORT).show();
                wastedTimeInCamera = secondsCounterCamera;
         //   Toast.makeText(getContext(), "Time In Camera: " + wastedTimeInCamera, Toast.LENGTH_SHORT).show();
                cameraTimer.cancel();

        }

        sensorManager.registerListener(
                sensorListener,
                accelerometer,
                SensorManager.SENSOR_DELAY_NORMAL
        );

        sensorManager.registerListener(
                sensorListener,
                gravitySensor,
                SensorManager.SENSOR_DELAY_NORMAL
        );

//        IntentFilter filter = new IntentFilter();
//        filter.addAction(Intent.ACTION_SCREEN_ON);
//        filter.addAction(Intent.ACTION_SCREEN_OFF);
//        registerReceiver(screenReceiver, filter);
//        screenReceiverRegistered = true;
//
//        sensorManager.registerListener(sensorListener,
//                sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
//                SensorManager.SENSOR_DELAY_NORMAL);


//        sensorManager.registerListener(
//                sensorListener,
//                pressureSensor,
//                SensorManager.SENSOR_DELAY_NORMAL
//        );

    }


    ///////////NOT SURE IF THIS IS NEEDED....!?!?!?!?
    @Override
    public void onPause() {
        super.onPause();
        sensorManager.unregisterListener(sensorListener);

//        if (screenReceiverRegistered) {
//            unregisterReceiver(screenReceiver);
//            screenReceiverRegistered = false;
//        }
    }


//    /// BroadcastReceiver in Order to know if Phone is used!!!!!!!!!!!!!!!
//    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
//        @Override
//        public void onReceive(Context context, Intent intent) {
//            if (Intent.ACTION_SCREEN_ON.equals(intent.getAction())) {
//                screenOn = true;
//            } else if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) {
//                screenOn = false;
//            }
//        }
//    };


    public void skippedCheckpoint() {
        skippedCheckpoint = true;
        goingToCheckpointCode = recoveryCheckpointCode;
        AlertDialog dialog = new AlertDialog.Builder(requireContext(), R.style.myTheme)
                .setTitle("Are you sure you have chosen the right checkpoint?")
                .setMessage("It seems as if you have skipped one or more checkpoints. Please submit all forgotten checkpoints")
                .setPositiveButton("Okay", (d, which) -> d.dismiss())
                .create();
        dialog.show();
        /// DEACTIVATE The time you have spent on camera since this might be quite some time... further make sure that no AdditionalTimeForReturnTimer is added ...safety messure
    }

    public void twiceTheSameCheckpoint() {
        String alertText;
        String alertTextHead;
        if(ButtonReached.getVisibility() == View.GONE || ButtonReached.getVisibility() == View.INVISIBLE) {
            alertTextHead = "You have already reached this checkpoint";
            alertText = "Please choose a new destination to explore";
        } else {
            alertTextHead = "You already have submitted "+  goingToCheckpointCode + " as your goal";
            alertText = "Please continue to reach it";
        }
        AlertDialog dialog = new AlertDialog.Builder(requireContext(), R.style.myTheme)
                .setTitle(alertTextHead)
                .setMessage(alertText)
                .setPositiveButton("Okay", (d, which) -> d.dismiss())
                .create();
        dialog.show();
    }








    /// ATTENTION!!!! THIS HERE IS CODED AS FOLLOWED: the Code checks the place from where you have been PREVIOUSLY and then checks if the CHECKPOINT you are NOW is reachable from there and if so, in what time etc.
    //Startpoint: ENTRANCE
    public boolean whatCheckpointAndTimeAdaptation() { /// This Code was rewritten, hence the unnecessary many ifs instead of && - it was easier to reuse the layout of adaptTime()
        boolean allowed = false;
        if ("0".equals(previousCheckpointCode)) {
            if ("Checkpoint: Wooden Bridge".equals(goingToCheckpointCode)) {
                allowed = true;
            } else {
                //USER SKIPPED A CHECKPOINT...   THis is the POP-UP Window in case you have gone From Start of the Cave to a checkpoint that would not be next
                skippedCheckpoint();
            }
        }

        //Startpoint: WOODEN BRIDGE
        else if ("Checkpoint: Wooden Bridge".equals(previousCheckpointCode)) {
            if ("Checkpoint: Wooden Bridge".equals(goingToCheckpointCode)) {
                twiceTheSameCheckpoint();
            } else if ("Checkpoint: Narrow Passage".equals(goingToCheckpointCode)) {
                allowed = true;
            } else if ("Checkpoint: Gigantic Collum".equals(goingToCheckpointCode)) {
                allowed = true;
            } else if ("Checkpoint: Paradisehall".equals(goingToCheckpointCode)) {
                allowed = true;
            } else if ("Checkpoint: Cross-Crevices".equals(goingToCheckpointCode)) {
                allowed = true;
            } else {
                skippedCheckpoint();
            }
        }

        //Startpoint: NARROW PASSAGE
        else if ("Checkpoint: Narrow Passage".equals(previousCheckpointCode)) {
            if ("Checkpoint: Narrow Passage".equals(goingToCheckpointCode)) {
                twiceTheSameCheckpoint();
            } else if ("Checkpoint: Wooden Bridge".equals(goingToCheckpointCode)) {
                allowed = true;
           //     Toast.makeText(getContext(), "THIS FRICKIN WORKS: Wooden Bridge", Toast.LENGTH_SHORT).show();
            } else if ("Checkpoint: Salzmännchen".equals(goingToCheckpointCode)) {
                allowed = true;
           //     Toast.makeText(getContext(), "THIS FRICKIN WORKS: Salzmännchen", Toast.LENGTH_SHORT).show();
            } else if ("Checkpoint: Cross-Crevices".equals(goingToCheckpointCode)) {
                allowed = true;
         //       Toast.makeText(getContext(), "THIS FRICKIN WORKS: Narrow Passage", Toast.LENGTH_SHORT).show();
            } else {
                skippedCheckpoint();
            }
        }

        //Startpoint: SALZMÄNNCHEN
        else if ("Checkpoint: Salzmännchen".equals(previousCheckpointCode)) {
            if ("Checkpoint: Salzmännchen".equals(goingToCheckpointCode)) {
                twiceTheSameCheckpoint();
            } else if ("Checkpoint: Narrow Passage".equals(goingToCheckpointCode)) {
                allowed = true;
          //      Toast.makeText(getContext(), "THIS FRICKIN WORKS: Narrow Passage", Toast.LENGTH_SHORT).show();
            } else if ("Checkpoint: Cross-Crevices".equals(goingToCheckpointCode)) {
                allowed = true;
          //      Toast.makeText(getContext(), "THIS FRICKIN WORKS: Narrow Passage", Toast.LENGTH_SHORT).show();
            } else {
                skippedCheckpoint();
            }
        }

        //Startpoint: POLDISPALTE
        else if ("Checkpoint: Gigantic Collum".equals(previousCheckpointCode)) {
            if ("Checkpoint: Gigantic Collum".equals(goingToCheckpointCode)) {
                twiceTheSameCheckpoint();
            } else if ("Checkpoint: Wooden Bridge".equals(goingToCheckpointCode)) {
                allowed = true;
         //       Toast.makeText(getContext(), "THIS FRICKIN WORKS: Wooden Bridge", Toast.LENGTH_SHORT).show();
            } else {
                skippedCheckpoint();
            }
        }

        //Startpoint: Kreuzspalten
        else if ("Checkpoint: Cross-Crevices".equals(previousCheckpointCode)) {
            if ("Checkpoint: Cross-Crevices".equals(goingToCheckpointCode)) {
                twiceTheSameCheckpoint();
            } else if ("Checkpoint: Wooden Bridge".equals(goingToCheckpointCode)) {
                allowed = true;
        //        Toast.makeText(getContext(), "THIS FRICKIN WORKS: Wooden Bridge", Toast.LENGTH_SHORT).show();
            } else if ("Checkpoint: Salzmännchen".equals(goingToCheckpointCode)) {
                allowed = true;
          //      Toast.makeText(getContext(), "THIS FRICKIN WORKS: Salzmännchen", Toast.LENGTH_SHORT).show();
                allowed = true;
            } else if ("Checkpoint: Paradisehall".equals(goingToCheckpointCode)) {
                allowed = true;
          //      Toast.makeText(getContext(), "THIS FRICKIN WORKS: Paradisehall", Toast.LENGTH_SHORT).show();
                allowed = true;
            } else if ("Checkpoint: Narrow Passage".equals(goingToCheckpointCode)) {
                allowed = true;
           //     Toast.makeText(getContext(), "THIS FRICKIN WORKS: Narrow Passage", Toast.LENGTH_SHORT).show();
            } else {
                skippedCheckpoint();
            }
        }

        //Startpoint: ParadisHalle
        else if ("Checkpoint: Paradisehall".equals(previousCheckpointCode)) {
            if ("Checkpoint: Paradisehall".equals(goingToCheckpointCode)) {
                twiceTheSameCheckpoint();
            } else if ("Checkpoint: Wooden Bridge".equals(goingToCheckpointCode)) {
                allowed = true;
          //      Toast.makeText(getContext(), "THIS FRICKIN WORKS: Wooden Bridge", Toast.LENGTH_SHORT).show();
            } else if ("Checkpoint: Cross-Crevices".equals(goingToCheckpointCode)) {
                allowed = true;
         //       Toast.makeText(getContext(), "THIS FRICKIN WORKS: Narrow Passage", Toast.LENGTH_SHORT).show();
            } else {
                skippedCheckpoint();
            }

        }
        //adaptingTimerEnabled = false;
        return allowed;
    }

    public void adaptingTime() {


        ButtonReached.setVisibility(View.GONE);

        timeSpentBetweenCheckpoints = timeStartGoingToCheckpoint- currentTimeLeftRETURNTimer;
        timeSpentBetweenCheckpoints -= (long) (wastedTimeInCamera*1000*0.75); //Subtraction of the time spent in the camera but only 75% of the time just to make sure there is rather more then less time for return!!!
        float terrainDifficulty = (float) (UP + DOWN) / (float) (timeSpentBetweenCheckpoints/1000) + (float) crawlingCount/ (float) (timeSpentBetweenCheckpoints/1000);
        /// NORMAL WALKING will get me 2-4%
        /// WALKING LIKE ON MORE DIFFICULT TERRAIN 5-12%
        /// THIS NEEEEED SO MUCH MORE TESTING!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        terrainDifficulty = (float) (terrainDifficulty - 0.05); // the quotient 0f 0-33.333% is normal walking, thus when it's almost normal walking u can go a bit faster on the way back usually since
        // dont take your time to look around - making it possible for the yellow Return bar to be smaller then the amount of time it took you to get to the checkpoint (minus timeWastedInCamera)

        Toast.makeText(getContext(), "Difficulty: " + terrainDifficulty*100, Toast.LENGTH_SHORT).show();

        UP = 0;
        DOWN =0;
        crawlingCount = 0;
        wastedTimeInCamera = 0; //Reset of wastedTimeInCamera

        if ("0".equals(previousCheckpointCode)) {
            if ("Checkpoint: Wooden Bridge".equals(goingToCheckpointCode)) {


                if (forgotToStartCheckpoint == true && timeSpentBetweenCheckpoints <= 30*1000) {  //If (Forgotten to start Timer AND the checkpoint was reached within 30sek, since the user already has been there
                    forgotToStartCheckpoint = false;
                    timeNeededToLeave = timeEntranceTOwooden;  //THIS IF IS NO LONGER NECESSARY..... could delete that.
                }
                else {
                    timeEntranceTOwooden = (long) (timeSpentBetweenCheckpoints * 1.1);
                    timeNeededToLeave = timeEntranceTOwooden;
                }

            } else {
                //USER SKIPPED A CHECKPOINT...   THis is the POP-UP Window in case you have gone From Start of the Cave to a checkpoint that would not be next
                skippedCheckpoint();
            }
        }

        //Startpoint: WOODEN BRIDGE
        else if ("Checkpoint: Wooden Bridge".equals(previousCheckpointCode)) {
            if ("Checkpoint: Wooden Bridge".equals(goingToCheckpointCode)) {
                twiceTheSameCheckpoint();
            } else if ("Checkpoint: Narrow Passage".equals(goingToCheckpointCode)) {
                timeNeededToLeave += timeSpentBetweenCheckpoints;

            } else if ("Checkpoint: Gigantic Collum".equals(goingToCheckpointCode)) {
                timeNeededToLeave += timeSpentBetweenCheckpoints;

            } else if ("Checkpoint: Paradisehall".equals(goingToCheckpointCode)) {
                timeNeededToLeave += timeSpentBetweenCheckpoints;

            } else if ("Checkpoint: Cross-Crevices".equals(goingToCheckpointCode)) {
                timeNeededToLeave += timeSpentBetweenCheckpoints;

            } else {
                skippedCheckpoint();
            }
        }

        //Startpoint: NARROW PASSAGE
        else if ("Checkpoint: Narrow Passage".equals(previousCheckpointCode)) {
            if ("Checkpoint: Narrow Passage".equals(goingToCheckpointCode)) {
                twiceTheSameCheckpoint();
            } else if ("Checkpoint: Wooden Bridge".equals(goingToCheckpointCode)) {
                timeNeededToLeave = timeEntranceTOwooden;

               // Toast.makeText(getContext(), "THIS FRICKIN WORKS: Wooden Bridge", Toast.LENGTH_SHORT).show();
            } else if ("Checkpoint: Salzmännchen".equals(goingToCheckpointCode)) {
                timeNeededToLeave += timeSpentBetweenCheckpoints;
                timeGoingBACK = timeSpentBetweenCheckpoints;

             //   Toast.makeText(getContext(), "THIS FRICKIN WORKS: Salzmännchen", Toast.LENGTH_SHORT).show();
            } else if ("Checkpoint: Cross-Crevices".equals(goingToCheckpointCode)) {
                timeNeededToLeave += (timeSpentBetweenCheckpoints * 0.6); //since the user actually almost goes back to WOODEN BRIDGE but then takes a different path which leads away from the entrance

             //   Toast.makeText(getContext(), "THIS FRICKIN WORKS: Narrow Passage", Toast.LENGTH_SHORT).show();
            } else {
                skippedCheckpoint();
            }
        }

        //Startpoint: SALZMÄNNCHEN
        else if ("Checkpoint: Salzmännchen".equals(previousCheckpointCode)) {
            if ("Checkpoint: Salzmännchen".equals(goingToCheckpointCode)) {
                twiceTheSameCheckpoint();
            } else if ("Checkpoint: Narrow Passage".equals(goingToCheckpointCode)) {
                timeNeededToLeave -= timeGoingBACK;
                timeGoingBACK = 0;

              //  Toast.makeText(getContext(), "THIS FRICKIN WORKS: Narrow Passage", Toast.LENGTH_SHORT).show();
            } else if ("Checkpoint: Cross-Crevices".equals(goingToCheckpointCode)) {
                timeNeededToLeave -= timeGoingBACK;
                timeGoingBACK = 0;
              //  Toast.makeText(getContext(), "THIS FRICKIN WORKS: Narrow Passage", Toast.LENGTH_SHORT).show();
            } else {
                skippedCheckpoint();
            }
        }

        //Startpoint: POLDISPALTE
        else if ("Checkpoint: Gigantic Collum".equals(previousCheckpointCode)) {
            if ("Checkpoint: Gigantic Collum".equals(goingToCheckpointCode)) {
                twiceTheSameCheckpoint();
            } else if ("Checkpoint: Wooden Bridge".equals(goingToCheckpointCode)) {
                timeNeededToLeave = timeEntranceTOwooden;

             //   Toast.makeText(getContext(), "THIS FRICKIN WORKS: Wooden Bridge", Toast.LENGTH_SHORT).show();
            } else {
                skippedCheckpoint();
            }
        }

        //Startpoint: Kreuzspalten
        else if ("Checkpoint: Cross-Crevices".equals(previousCheckpointCode)) {
            if ("Checkpoint: Cross-Crevices".equals(goingToCheckpointCode)) {
                twiceTheSameCheckpoint();
            } else if ("Checkpoint: Wooden Bridge".equals(goingToCheckpointCode)) {
                timeNeededToLeave = timeEntranceTOwooden;

             //   Toast.makeText(getContext(), "THIS FRICKIN WORKS: Wooden Bridge", Toast.LENGTH_SHORT).show();
            } else if ("Checkpoint: Salzmännchen".equals(goingToCheckpointCode)) {
                timeNeededToLeave += timeSpentBetweenCheckpoints;
                timeGoingBACK = timeSpentBetweenCheckpoints;

             //   Toast.makeText(getContext(), "THIS FRICKIN WORKS: Salzmännchen", Toast.LENGTH_SHORT).show();
            } else if ("Checkpoint: Paradisehall".equals(goingToCheckpointCode)) {
                timeNeededToLeave += (long) (timeSpentBetweenCheckpoints*0.7); //Since you have to climb up to go from Paradisehall to WOODEN BRIDGE it is likley that the user would have to go back eventhough this might not be the fastest route!

             //   Toast.makeText(getContext(), "THIS FRICKIN WORKS: Paradisehall", Toast.LENGTH_SHORT).show();
            } else if ("Checkpoint: Narrow Passage".equals(goingToCheckpointCode)) {
                timeNeededToLeave += (long) (timeSpentBetweenCheckpoints * 0.6); //since the user actually almost goes back to WOODEN BRIDGE but then takes a different path which leads away from the entrance

              //  Toast.makeText(getContext(), "THIS FRICKIN WORKS: Narrow Passage", Toast.LENGTH_SHORT).show();
            } else {
                skippedCheckpoint();
            }
        }

        //Startpoint: ParadisHalle
        else if ("Checkpoint: Paradisehall".equals(previousCheckpointCode)) {
            if ("Checkpoint: Paradisehall".equals(goingToCheckpointCode)) {
                twiceTheSameCheckpoint();
            } else if ("Checkpoint: Wooden Bridge".equals(goingToCheckpointCode)) {
                timeNeededToLeave = timeEntranceTOwooden;

            //    Toast.makeText(getContext(), "THIS FRICKIN WORKS: Wooden Bridge", Toast.LENGTH_SHORT).show();
            } else if ("Checkpoint: Cross-Crevices".equals(goingToCheckpointCode)) {
            //     Toast.makeText(getContext(), "THIS FRICKIN WORKS: Narrow Passage", Toast.LENGTH_SHORT).show();
                timeNeededToLeave += (long) (timeSpentBetweenCheckpoints*0.5); //Theoretically we wouldn't need do add time here it is quite likely that you can go directly to the WOODEN BRIDGE but it can't hurt to have a lil more time "for the "worst case scenario"
            } else {
                skippedCheckpoint();
            }

        }

        timeNeededToLeave = (long) (timeNeededToLeave + timeNeededToLeave*terrainDifficulty*2); //up to 10% can be subbtracted and about 10-20% added

        previousCheckpointCode = goingToCheckpointCode;
        if(currentTimeLeftCAVETimer - timeNeededToLeave > currentTimeLeftRETURNTimer + 1000*10) {
            millisReturnTimer = (long) (currentTimeLeftCAVETimer*0.975 - timeNeededToLeave) - pufferTime;
        }
        else millisReturnTimer = 1000*10;
    }


    private void updateTimeBar(long millisLeft) {


        float percentLeft = (float) millisLeft/ (float) maxTimeInCave; //Percentage of timeLeft compared to the overall Time in the beginning
        float percentTimeNeedToLeave = (float) timeNeededToLeave / (float) maxTimeInCave; //Quotient of the time needed for retreat and maxTime in cave
        int totalWeight = 100; //My bar is "100"-Bar-pieces


        int overBarLength = (int) (totalWeight * (1-percentLeft));
        int bufferBarLength = (int) (totalWeight * 0.25f);
        int returnBarLength = (int) (percentTimeNeedToLeave * totalWeight);
        int normalBarLength = (int) (totalWeight * percentLeft) - bufferBarLength - returnBarLength;


        if(normalBarLength < 0) {
            normalBarLength = 0;
            returnBarLength = (int) (totalWeight * percentLeft)- bufferBarLength;
        }

        if (currentTimeLeftCAVETimer < pufferTime) { // (((float) overBarLength / (float) totalWeight)
            bufferBarLength = totalWeight - overBarLength;
            returnBarLength = 0;
            normalBarLength = 0;

        }

        setWeight(bufferBar, bufferBarLength);
        setWeight(normalBar, normalBarLength);
        setWeight(returnBar, returnBarLength);
        setWeight(overBar, overBarLength);
    }

    private void setWeight(View v, int weight) {
        LinearLayout.LayoutParams lp =
                (LinearLayout.LayoutParams) v.getLayoutParams();
        lp.weight = weight;
        v.setLayoutParams(lp);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        handler.removeCallbacks(checkRunnable);
    }



/*
        @Override
        public void onDestroyView() {
            super.onDestroyView();
            if (timer != null) {
                timer.cancel();
            }
        }

*/



    }