package com.example.underpeak;

import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.media.Image;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.OpenForTesting;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class ImageDetailZOOMABLEActivity extends AppCompatActivity {

   // @Override
  //  protected void onCreate(Bundle savedInstanceState) {
     //   super.onCreate(savedInstanceState);
    //    EdgeToEdge.enable(this);
   //     setContentView(R.layout.activity_image_detail_zoomableactivity);
        //ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
          //  Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
           // v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
           // return insets;

                public static final String detail_image = "putExtra_image";

                @Override
                protected void onCreate(Bundle savedInstanceState) {
                    super.onCreate(savedInstanceState);
                    EdgeToEdge.enable(this);
                    setContentView(R.layout.activity_image_detail_zoomableactivity);

                    ImageView imageView = findViewById(R.id.ImageDetailID);

                    int image = getIntent().getIntExtra(detail_image, 0);
                    String imageUriString = getIntent().getStringExtra(detail_image);

                    if(image != 0) imageView.setImageResource(image);
                    else {
                        Uri imageUri = Uri.parse(imageUriString);
                        imageView.setImageURI(imageUri);
                    }
                }
            }
