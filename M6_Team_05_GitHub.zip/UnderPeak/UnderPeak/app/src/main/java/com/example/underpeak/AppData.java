package com.example.underpeak;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;

public class AppData {

    // ---------------------------------------------------------
    // 1) MASTER CAVE DATA (The "Single Source of Truth")
    // ---------------------------------------------------------
    public static ArrayList<CustomModel> getAllCaves() {
        ArrayList<CustomModel> list = new ArrayList<>();

        // 1
        list.add(new CustomModel(
                R.drawable.binghohle,
                "Binghöhle",
                "Streitberg, 25 km",
                "4.8 (324 reviews)",
                "Moderate",
                25,
                95,
                "Dolomite",
                new String[]{"Stalactites", "Dripstone", "Guided Tours", "Lighting"},
                "The Bighöhle is a natural limestone cave located in the Franconian Jura, a region shaped by karst processes. It was formed through the long-term chemical weathering of limestone by slightly acidic groundwater, which dissolved the rock along cracks and bedding planes. Over thousands to millions of years, this process created underground cavities and passages. The cave has remained largely in its natural state and is not developed for tourism. Because of this, it provides valuable insight into undisturbed karst systems and underground erosion processes. Scientists study such caves to better understand groundwater flow and the geological evolution of limestone landscapes."
        ));

        // 2
        list.add(new CustomModel(
                R.drawable.pic2,
                "Teufelshöhle",
                "Pottenstein, 18 km",
                "4.9 (567 reviews)",
                "Easy",
                18,
                60,
                "Limestone",
                new String[]{"Family Friendly", "Guided Tours", "Large Chambers", "Lighting"},
                "The Teufelshöhle is one of the largest and most significant karst caves in Germany. It consists of vast chambers and extensive dripstone formations, including stalactites and stalagmites formed by mineral-rich water dripping over long periods of time. The cave developed during different geological phases, which can be identified by varying sediment layers and mineral deposits. Its constant temperature and humidity create a stable microclimate, ideal for preserving geological structures. The cave is also of scientific importance because it provides information about past climatic conditions through its calcite formations. Today, it serves both as a research site and as an educational show cave."
        ));

        // 3
        list.add(new CustomModel(
                R.drawable.sophienhohle,
                "Sophienhöhle",
                "Burg Rabenstein, 22 km",
                "4.7 (289 reviews)",
                "Moderate",
                22,
                70,
                "Limestone",
                new String[]{"Dripstone", "Guided Tours", "Cool Temperature"},
                "The Sophienhöhle is scientifically important due to its combination of geological and archaeological features. Geologically, it is a classic limestone cave formed by karstification and later shaped by sediment deposition. Archaeological excavations have revealed bones of Ice Age animals such as cave bears, showing that the cave served as a natural shelter. These remains provide valuable information about prehistoric fauna and environmental conditions. The cave’s dripstone formations also record changes in climate over thousands of years. As a result, the Sophienhöhle is an important site for both paleontology and climate research."
        ));

        // 4
        list.add(new CustomModel(
                R.drawable.oswaldhohle,
                "Oswaldhöhle",
                "Muggendorf, 30 km",
                "4.5 (156 reviews)",
                "Difficult",
                30,
                85,
                "Karst",
                new String[]{"Natural Entrance", "Forest Trail", "Less Crowded"},
                "The Oswaldhöhle is a tunnel-like karst cave with openings at both ends, allowing daylight to pass through. It was formed by an underground river that gradually enlarged natural fissures in the limestone. The cave contains sediments that indicate repeated flooding events in the past. Archaeological findings suggest that humans and animals used the cave intermittently during prehistoric times. Because it is easily accessible and naturally ventilated, it offers scientists a clear example of erosion-driven cave development. The Oswaldhöhle is also important for studying interactions between humans and natural cave environments."
        ));

        // 5
        list.add(new CustomModel(
                R.drawable.rosenmullershohle,
                "Rosenmüllerhöhle",
                "Muggendorf, 28 km",
                "4.6 (203 reviews)",
                "Difficult",
                28,
                90,
                "Karst",
                new String[]{"Narrow Passages", "Rock Formations", "Natural Light"},
                "The Rosenmüllerhöhle is a smaller cave that holds scientific interest mainly for its historical and environmental context. It was formed through the same karst processes typical of the region, though on a smaller scale. The cave has relatively few dripstone formations, suggesting limited mineral-rich water flow. Historical evidence indicates that it was used by hermits, which provides insight into human use of caves beyond prehistory. From a scientific perspective, it helps researchers understand how small karst cavities evolve over time. It also demonstrates how humans adapt natural geological spaces for habitation."
        ));

        // 6
        list.add(new CustomModel(
                R.drawable.maximiliansgrotte,
                "Maximiliansgrotte",
                "Krottensee, 35 km",
                "4.8 (412 reviews)",
                "Moderate",
                35,
                110,
                "Limestone",
                new String[]{"Crystal Formations", "Guided Tours", "Cave Pearls"},
                "The Maximiliansgrotte is a well-studied karst cave known for its exceptionally large stalactite, the largest in Germany. The cave’s formations developed through slow precipitation of calcium carbonate from dripping water. These formations act as natural climate archives, recording variations in temperature and rainfall. Sediment layers inside the cave provide evidence of different geological phases. Because the cave is well preserved and accessible, it has been extensively studied by geologists. It also plays an important role in public education about karst geology."
        ));

        // 7
        list.add(new CustomModel(
                R.drawable.esperhohle,
                "Esperhöhle",
                "Burg Rabenstein, 23 km",
                "4.3 (178 reviews)",
                "Easy",
                23,
                55,
                "Limestone",
                new String[]{"Short Walk", "Family Friendly", "Historical Site"},
                "The Esperhöhle is one of the longest cave systems in the Franconian Jura and is of major speleological importance. Its extensive network of passages reflects complex underground water systems. The cave is largely undeveloped and therefore preserves natural conditions. It serves as an important habitat for bats and other cave-adapted species, making it relevant for ecological studies. Due to its size and complexity, the Esperhöhle is used to study cave formation, biodiversity, and groundwater movement. It is protected to prevent damage to its fragile ecosystem."));

        // 8
        list.add(new CustomModel(
                R.drawable.wunderhohle,
                "Wunderhöhle",
                "Engelhardsberg, 32 km",
                "4.7 (89 reviews)",
                "Expert",
                32,
                120,
                "Karst",
                new String[]{"Advanced Terrain", "Helmet Required", "Deep Shafts"},
                "The Wunderhöhle is a smaller karst cave known for unusual limestone structures. These formations result from specific chemical conditions during mineral deposition. The cave provides scientists with insight into localized variations in karst development. Although it does not contain large chambers, it is valuable for understanding small-scale cave formation processes. Its preservation allows for detailed geological observation. The cave is mainly of interest to researchers rather than tourists." ));

        // 9
        list.add(new CustomModel(
                R.drawable.pic2,
                "Schönsteinhöhle",
                "Pottenstein, 20 km",
                "4.8 (103 reviews)",
                "Easy",
                20,
                78,
                "Limestone",
                new String[]{"Guided tours", "Family Friendly", "Dripstone formations" , "Easy accessible"},
                "The Schönsteinhöhle is a natural limestone cave characterized by its relatively undisturbed state. It represents a typical karst cave formed through long-term chemical erosion. The lack of heavy tourism makes it suitable for studying natural cave conditions without human influence. Its rock formations provide information about water flow and mineral deposition. Scientists value the cave as a reference site for comparing altered and unaltered cave environments. It also contributes to understanding regional karst development."
        ));

        return list;
    }

    // ---------------------------------------------------------
    // 2) FAVORITES FILTER LOGIC
    // ---------------------------------------------------------
    /**
     * This method ensures the Saved Fragment only shows caves
     * that exist in the FavoritesManager.
     */
    public static ArrayList<CustomModel> getSavedCaves(Context context) {
        ArrayList<CustomModel> allCaves = getAllCaves();
        ArrayList<CustomModel> savedList = new ArrayList<>();

        for (CustomModel cave : allCaves) {
            if (FavoritesManager.isFavorite(context, cave.getTitle())) {
                savedList.add(cave);
            }
        }
        return savedList;
    }

    // ---------------------------------------------------------
    // 3) HOME SCREEN PREVIEW
    // ---------------------------------------------------------
    /** public static ArrayList<CustomModel> getHomePreviewCaves() {
        ArrayList<CustomModel> all = getAllCaves();
        ArrayList<CustomModel> preview = new ArrayList<>();
        // Just take the first 2 caves for the home screen horizontal/vertical preview
        for (int i = 0; i < Math.min(2, all.size()); i++) {
            preview.add(all.get(i));
        }
        return preview;
    } **/

    // ---------------------------------------------------------
    // 4) BEGINNER GUIDE DATA
    // ---------------------------------------------------------
    public static List<BeginnerCardItem> getBeginnerGuideItems() {
        ArrayList<BeginnerCardItem> list = new ArrayList<>();

        // HERO
        list.add(BeginnerCardItem.hero(
                R.drawable.cave_hero, // replace/add this drawable
                "Cave Exploring",
                "A Beginner's Guide to Underground Adventure"
        ));

        // Intro paragraph
        list.add(BeginnerCardItem.paragraph(
                "Cave exploring (spelunking) is an exciting adventure into the underground world. "
                        + "This guide helps you start safely and responsibly."
        ));

        // SECTION: Safety First
        list.add(BeginnerCardItem.section("Safety First", R.drawable.ic_warning));
        list.add(BeginnerCardItem.simpleCard(
                "Never Go Alone",
                "Always explore caves with at least two other people. A safe beginner group is three."
        ));
        list.add(BeginnerCardItem.simpleCard(
                "Tell Someone Your Plans",
                "Tell a friend where you go and when you should return. If possible share your route."
        ));
        list.add(BeginnerCardItem.simpleCard(
                "Know Your Limits",
                "Start with easy caves. Don’t attempt advanced caves until trained and experienced."
        ));
        list.add(BeginnerCardItem.simpleCard(
                "Check Weather Conditions",
                "Avoid caves during heavy rain. Flooding can occur rapidly."
        ));

        // SECTION: Essential Equipment
        list.add(BeginnerCardItem.section("Essential Equipment", R.drawable.ic_bag));
        list.add(BeginnerCardItem.imageCard(
                R.drawable.helmet_img, // replace/add this drawable
                "Lighting System",
                "Carry 3 independent light sources per person (primary, backup, emergency)."
        ));
        list.add(BeginnerCardItem.imageCard(
                R.drawable.protection_img, // replace/add this drawable
                "Protective Gear",
                "Helmet with chin strap, durable clothing, gloves, and sturdy boots."
        ));
        list.add(BeginnerCardItem.bulletCard(
                "Navigation & Communication",
                new String[]{
                        "Cave map or guidebook",
                        "Whistle (emergency signal)",
                        "First aid kit",
                        "Power bank (optional)",
                        "Rope only if needed for your route"
                }
        ));
        list.add(BeginnerCardItem.bulletCard(
                "Additional Essentials",
                new String[]{
                        "Extra batteries for all lights",
                        "Water + high-energy snacks",
                        "Change of clothes (leave in car)",
                        "Emergency blanket",
                        "Trash bag (pack out everything)"
                }
        ));

        // SECTION: Getting Started
        list.add(BeginnerCardItem.section("Getting Started", R.drawable.ic_book));
        list.add(BeginnerCardItem.numberedCard(
                1, "Join a Caving Club or Group",
                "Go with experienced cavers. They can teach safety and recommend beginner routes."
        ));
        list.add(BeginnerCardItem.numberedCard(
                2, "Start with Commercial Caves",
                "Guided tours with lighting and paths are perfect for beginners."
        ));
        list.add(BeginnerCardItem.numberedCard(
                3, "Learn Cave Conservation",
                "Take only pictures, leave only footprints. Formations take thousands of years."
        ));

        // SECTION: Cave Conservation Ethics
        list.add(BeginnerCardItem.section("Cave Conservation Ethics", R.drawable.ic_shield));
        list.add(BeginnerCardItem.bulletCard(
                "Leave No Trace",
                new String[]{
                        "Don’t touch formations (skin oils stop growth)",
                        "Pack out all trash",
                        "Stay on paths where possible",
                        "Don’t remove rocks or artifacts"
                }
        ));
        list.add(BeginnerCardItem.bulletCard(
                "Respect Wildlife",
                new String[]{
                        "Never disturb bats or cave creatures",
                        "Avoid caves during bat hibernation season",
                        "Keep noise low"
                }
        ));

        // SECTION: Helpful Tips
        list.add(BeginnerCardItem.section("Helpful Tips for Beginners", R.drawable.ic_location));
        list.add(BeginnerCardItem.simpleCard(
                "Temperature",
                "Caves stay cool year-round (often ~10–15°C). Dress in layers."
        ));
        list.add(BeginnerCardItem.simpleCard(
                "Move Slowly",
                "Rushing increases injury risk and makes you miss formations."
        ));
        list.add(BeginnerCardItem.simpleCard(
                "Emergency Signal",
                "Know the distress signal: three short whistle blasts."
        ));

        return list;
    }
}













