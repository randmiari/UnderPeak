package com.example.underpeak;
import static androidx.core.content.ContentProviderCompat.requireContext;
import static java.security.AccessController.getContext;

import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import com.example.underpeak.ImageRepository;
import com.example.underpeak.CapturedImage;



public class JourneyOverviewActivity extends AppCompatActivity {

    private String duration;
    private TextView durationText;
    private TextView dateText;
    private Button exitButton;
    private long startTime = -1;
    private String team;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        EdgeToEdge.enable(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_journeyoverview);


        /// GET and SET the DATE & DURATION of the tour!!!
        durationText = findViewById(R.id.durationID);
        dateText = findViewById(R.id.dateID);


        //setting the Date
        long today = System.currentTimeMillis();
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());
        String currentDate = sdf.format(new Date(today));
        dateText.setText("Date: " + currentDate);

        //setting the duration
        Intent intent = getIntent();
        startTime = intent.getLongExtra("START_TIME", -1);
        if (startTime != -1) {

            long duration = System.currentTimeMillis() - startTime;

            long seconds = duration / 1000;
            long hours = seconds / 3600;
            long minutes = (seconds % 3600) / 60;
            long secs = seconds % 60;

            //Making sure that 1:1:10 and 1:13:1 doesn't appear but always 2:01:03
            String minutesS = Long.toString(minutes);
            String secsS = Long.toString(secs);
            if (minutes < 10) minutesS = "0" + minutesS;
            if (secs < 10) secsS = "0" + secsS;

            this.duration = "Duration: " + hours + ":" + minutesS + ":" + secsS;

        } else duration = "This cave tour is still ongoing";
        if (startTime == Long.MAX_VALUE) duration = "This tour has never been initiated";

        durationText.setText(duration); /// END


        ///Making sure that you cannot go back to the CavingActivity once you have ENDED it!!
        if (startTime != -1) {
            getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
                @Override
                public void handleOnBackPressed() {
                    //"going back" should be now deactivated
                }
            });
        } ///END


        ArrayList<CapturedImage> images = ImageRepository.getImages();

        /// Sorting Images after TimeOfTaking
        Collections.sort(images, (a, b) ->
                Long.compare(a.getTime(), b.getTime())
        );

        ///  Making the ITEMS for the Adapter and "Feeding" the Adapter with them(?!)
        List<ImageItemTimeline> timelineItems = new ArrayList<>();
        for (CapturedImage img : images) {
            String head = new java.text.SimpleDateFormat("HH:mm:ss").format(new java.util.Date(img.getTime()));
            String body = img.getCheckpoint();
            timelineItems.add(new ImageItemTimeline(head, body, img.getUri()));
        }

        ImageTimelineAdapter adapter = new ImageTimelineAdapter(this, timelineItems, startTime);
        ListView listView = findViewById(R.id.ListViewJourneyID);

        /// Adding a Editable LIST FOOT for HIGHLIGHTS!!!!
        View footView = getLayoutInflater().inflate(R.layout.list_foot, listView, false);
        listView.addFooterView(footView); ///END

        /// Editing the HIGHTLIGHTS!!!
        TextView footText = footView.findViewById(R.id.tourBottomTextID);
        TextView footHighlightText = footView.findViewById(R.id.tourBottomHighlightsID);
        footView.setOnClickListener(v -> {

            if (startTime != -1) {

                View dialogView = LayoutInflater.from(JourneyOverviewActivity.this)
                        .inflate(R.layout.dialog_edit_item, null);

                EditText editHead = dialogView.findViewById(R.id.editHead);
                EditText editBody = dialogView.findViewById(R.id.editBody);

                //the old text again
                editBody.setText(footText.getText());
                editHead.setText(footHighlightText.getText());

                new AlertDialog.Builder(JourneyOverviewActivity.this, R.style.myTheme)
                        .setTitle("Edit Item")
                        .setView(dialogView)
                        .setPositiveButton("Save", (dialog, which) -> {
                            footText.setText(editBody.getText().toString());
                            footHighlightText.setText(editHead.getText().toString());
                            //notifyDataSetChanged();
                        })
                        .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                        .show();

            } else {
                AlertDialog dialog = new AlertDialog.Builder(JourneyOverviewActivity.this, R.style.myTheme)
                        .setTitle("Sorry, editing not yet possible")
                        .setMessage("Please stay focussed on your journey. Editing will be possible after you have finished your cave-tour")
                        .setPositiveButton("Okay", (d, which) -> d.dismiss())
                        .create();
                dialog.show();//this is in case the tour is not finished yet - we dont want people to spend time inside the cave on their phone too much
            }

        }); ///END













        /// Making the Close journey button only appear once the TOUR HAS FOUND ITS END
        exitButton = footView.findViewById(R.id.exitButtonID);
        if (startTime != -1) {
            exitButton.setOnClickListener(v -> {

                if("This tour has never been initiated".equals(duration)) {
                    new AlertDialog.Builder(this, R.style.myTheme)
                            .setTitle("Delete this journey?")
                            .setMessage("Since you never have initiated this journey - do you wish to delete it? Be aware that saving might take a few seconds")
                            // .setView(input)
                            .setPositiveButton("Yes, delete it", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {;
                                    timelineItems.clear();
                                    ImageRepository.clear();
                                    adapter.notifyDataSetChanged();
                                    Intent intent2 = new Intent(JourneyOverviewActivity.this, MainActivity.class);
                                    startActivity(intent2);
                                }
                            })
                            .setNegativeButton("Save it", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    // team = input.getText().toString();
                                    exportFullLayoutToPdf();
                                    timelineItems.clear();
                                    ImageRepository.clear();
                                    adapter.notifyDataSetChanged();
                                    Intent intent2 = new Intent(JourneyOverviewActivity.this, MainActivity.class);
                                    startActivity(intent2);
                                }
                            }).show();
                } else {
/// THIS WAS SUPPOSED TO ADD THE TEAM MEMBER NAMES... i decited not to do this like that for now.
//                exitButton.setVisibility(View.GONE);
//                EditText input = new EditText(this);
//                int paddingDp = 16;
//                float scale = getResources().getDisplayMetrics().density;
//                int paddingPx = (int) (paddingDp * scale + 0.5f);
//
//// Padding setzen: links, top, rechts, bottom
//                input.setPadding(paddingPx, input.getPaddingTop(), paddingPx, input.getPaddingBottom());
//                input.setHint("Please submit the names of your expedition members");

// INSERTING THE TEAM MEMBERS!!!!
                new AlertDialog.Builder(this, R.style.myTheme)
                        .setTitle("Exporting as PDF")
                        .setMessage("By clicking on OK your project will be exported. After that the Journey is no longer editable. You will find the PDF in your downloads folder or listed under \"My Adventures\". Be aware that saving your Timeline might take a few seconds.")
                       // .setView(input)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                               // team = input.getText().toString();
                                exportFullLayoutToPdf();

                                timelineItems.clear();
                                ImageRepository.clear();
                                adapter.notifyDataSetChanged();
                                Intent intent2 = new Intent(JourneyOverviewActivity.this, MainActivity.class);
                                startActivity(intent2);


                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();

                }
            });

        } else exitButton.setVisibility(View.GONE);


        listView.setAdapter(adapter);
    }
    public void exportFullLayoutToPdf() {
        exitButton.setVisibility(View.GONE);
        View rootContent = findViewById(R.id.rootID);
        ListView listView = findViewById(R.id.ListViewJourneyID);
        LinearLayout header = findViewById(R.id.OverviewHeadID);
        ListAdapter adapter = listView.getAdapter();

        if (adapter == null) return;

        // --- 1. BACKUP DER ORIGINAL-WERTE ---
        ViewGroup.LayoutParams params = listView.getLayoutParams();
        int originalHeight = params.height;
        ConstraintLayout.LayoutParams lp = (ConstraintLayout.LayoutParams) listView.getLayoutParams();
        int originalTopMargin = lp.topMargin;
        int originalPaddingTop = listView.getPaddingTop();

        // --- 2. BILDER IN DER ECHTEN LISTE KOMPRIMIEREN ---
        // Wir gehen durch alle aktuell geladenen Views der ListView
        for (int i = 0; i < listView.getChildCount(); i++) {
            View listItem = listView.getChildAt(i);
            if (listItem != null) {
                ImageView imageView = listItem.findViewById(R.id.ImageID);
                if (imageView != null && imageView.getDrawable() instanceof BitmapDrawable) {
                    Bitmap bitmap = ((BitmapDrawable) imageView.getDrawable()).getBitmap();

                    // Hier rufen wir deine Methode auf
                    Bitmap compressed = compressBitmap(bitmap);

                    // Wir setzen das komprimierte Bild direkt in die sichtbare View
                    imageView.setImageBitmap(compressed);
                }
            }
        }

        // --- 3. LAYOUT FÜR EXPORT "STRECKEN" (Dein Code) ---
        int totalItemsHeight = 0;
        for (int i = 0; i < adapter.getCount(); i++) {
            View listItem = adapter.getView(i, null, listView);
            // Hinweis: Hier messen wir nur die Höhe, die Kompression oben
            // sorgt dafür, dass die echten Views später klein gezeichnet werden.
            listItem.measure(
                    View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            );
            totalItemsHeight += listItem.getMeasuredHeight();
        }

        lp.height = totalItemsHeight + (listView.getDividerHeight() * (adapter.getCount() - 1));
        lp.topMargin = -2;
        lp.setMargins(0, -2, 0, 0);

        listView.setLayoutParams(lp);
        listView.setPadding(0, 0, 0, 0);
        listView.setDividerHeight(0);

        ConstraintLayout.LayoutParams headerLp = (ConstraintLayout.LayoutParams) header.getLayoutParams();
        int originalHeaderBottomMargin = headerLp.bottomMargin;
        headerLp.bottomMargin = 0;
        header.setLayoutParams(headerLp);

        // --- 4. MESSEN & ZEICHNEN ---
        rootContent.measure(
                View.MeasureSpec.makeMeasureSpec(rootContent.getWidth(), View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        );

        int totalWidth = rootContent.getMeasuredWidth();
        int totalHeight = rootContent.getMeasuredHeight();

        PdfDocument pdfDocument = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(totalWidth, totalHeight, 1).create();
        PdfDocument.Page page = pdfDocument.startPage(pageInfo);

        Canvas canvas = page.getCanvas();
        rootContent.layout(0, 0, totalWidth, totalHeight);
        rootContent.draw(canvas); // Hier landet jetzt die Kompression im PDF!

        // --- 5. TIMELINE BRIDGE & TEXT (Dein Code) ---
        float density = getResources().getDisplayMetrics().density;
        float linePaddingLeft = 20 * density;
        float lineWidth = 10 * density;
        float startY = header.getBottom();
        float endY = startY + (128 * density);

        Paint paint = new Paint();
        paint.setColor(Color.parseColor("#5f1654"));
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRect(linePaddingLeft, startY, linePaddingLeft + lineWidth, endY, paint);

        Paint textPaint = new Paint();
        textPaint.setColor(Color.parseColor("#f7d2fe"));
        textPaint.setTextSize(20 * density);
        textPaint.setAntiAlias(true);
        textPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));

        float textX = linePaddingLeft + lineWidth + (10 * density);
        float textY = startY + (25 * density);
        canvas.drawText("Coordinates of the Entrance: ", textX+5, textY+20, textPaint);
        canvas.drawText(" 49°55'42.0\"N 11°35'02.7\"E", textX+5, textY+65, textPaint);
        canvas.drawCircle(linePaddingLeft + (lineWidth / 2), startY, lineWidth * 0.8f, paint);

        pdfDocument.finishPage(page);
        savePdfToDownloads(pdfDocument);

        // --- 6. ALLES ZURÜCKSETZEN ---
        lp.height = originalHeight;
        lp.topMargin = originalTopMargin;
        listView.setLayoutParams(lp);
        listView.setPadding(0, originalPaddingTop, 0, 0);

        headerLp.bottomMargin = originalHeaderBottomMargin;
        header.setLayoutParams(headerLp);

        // WICHTIG: Adapter neu laden, damit die Bilder in der App wieder scharf werden
        listView.setAdapter(adapter); ///I THINK THIS IS NOT NECESSARY SINCE I DELETE THEM ANYWAY...
        rootContent.requestLayout();
    }

//     public void exportFullLayoutToPdf() {
//         View rootContent = findViewById(R.id.rootID);
//         ListView listView = findViewById(R.id.ListViewJourneyID);
//         LinearLayout header = findViewById(R.id.OverviewHeadID);
//         ListAdapter adapter = listView.getAdapter();
//
//         if (adapter == null) return;
//
//         ViewGroup.LayoutParams params = listView.getLayoutParams();
//         int originalHeight = params.height;
//         ConstraintLayout.LayoutParams lp = (ConstraintLayout.LayoutParams) listView.getLayoutParams();
//         int originalTopMargin = lp.topMargin;
//         int originalPaddingTop = listView.getPaddingTop();
//
//
//         int totalItemsHeight = 0;
//         for (int i = 0; i < adapter.getCount(); i++) {
//             View listItem = adapter.getView(i, null, listView);
//
//             /// KOMPRESSION
//             ImageView imageView = listItem.findViewById(R.id.ImageID);
//             if (imageView != null && imageView.getDrawable() instanceof BitmapDrawable) {
//
//                 Bitmap bitmap = ((BitmapDrawable) imageView.getDrawable()).getBitmap();
//                 imageView.setImageBitmap(compressBitmap(bitmap));
//             }
//
//
//
//             listItem.measure(
//                     View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.EXACTLY),
//                     View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
//             );
//             totalItemsHeight += listItem.getMeasuredHeight();
//         }
//
//         lp.height = totalItemsHeight + (listView.getDividerHeight() * (adapter.getCount() - 1));
//         lp.topMargin = -2;
//         lp.setMargins(0, -2, 0, 0);
//
//         listView.setLayoutParams(lp);
//         listView.setPadding(0, 0, 0, 0);
//         listView.setDividerHeight(0);
//
//
//         ConstraintLayout.LayoutParams headerLp = (ConstraintLayout.LayoutParams) header.getLayoutParams();
//         int originalHeaderBottomMargin = headerLp.bottomMargin;
//         headerLp.bottomMargin = 0;
//         header.setLayoutParams(headerLp);
//
//
//         rootContent.measure(
//                 View.MeasureSpec.makeMeasureSpec(rootContent.getWidth(), View.MeasureSpec.EXACTLY),
//                 View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
//         );
//
//         int totalWidth = rootContent.getMeasuredWidth();
//         int totalHeight = rootContent.getMeasuredHeight();
//
//         PdfDocument pdfDocument = new PdfDocument();
//         PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(totalWidth, totalHeight, 1).create();
//         PdfDocument.Page page = pdfDocument.startPage(pageInfo);
//
//         Canvas canvas = page.getCanvas();
//         rootContent.layout(0, 0, totalWidth, totalHeight);
//         rootContent.draw(canvas);
//
//
//
//
//         Canvas canvas1 = page.getCanvas();
//
//         float density = getResources().getDisplayMetrics().density;
//         float linePaddingLeft = 20 * density;
//         float lineWidth = 10 * density;
//
//         View header1 = findViewById(R.id.OverviewHeadID);
//         float startY = header1.getBottom();
//
//
//         float endY = startY + (128 * density);
//
//
//         Paint paint = new Paint();
//         paint.setColor(Color.parseColor("#5f1654"));
//         paint.setStyle(Paint.Style.FILL);
//
//
//         canvas1.drawRect(
//                 linePaddingLeft,
//                 startY,
//                 linePaddingLeft + lineWidth,
//                 endY,
//                 paint
//         );
//
//
//         Paint textPaint = new Paint();
//         textPaint.setColor(Color.parseColor("#f7d2fe"));
//         textPaint.setTextSize(20 * density);
//         textPaint.setAntiAlias(true);
//         textPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
//
//
//         float textX = linePaddingLeft + lineWidth + (10 * density);
//
//         float textY = startY + (25 * density);
//
//
//         canvas.drawText("Coordinates of the Entrance: ", textX+5, textY+20, textPaint);
//         canvas.drawText(" 49°55'42.0\"N 11°35'02.7\"E", textX+5, textY+65, textPaint);
//
//         canvas.drawCircle(
//                 linePaddingLeft + (lineWidth / 2),
//                 startY,
//                 lineWidth * 0.8f,
//                 paint
//         );
//
//
////         textPaint.setTextSize(10 * density);
////         textPaint.setColor(Color.GRAY);
////         canvas.drawText("System ready - Sensors active", textX, textY + (15 * density), textPaint);
//
//// ... (vor pdfDocument.finishPage(page))
//
//         pdfDocument.finishPage(page);
//
//         savePdfToDownloads(pdfDocument);
//         // Alles zurücksetzen
//         lp.height = originalHeight;
//         lp.topMargin = originalTopMargin;
//         listView.setLayoutParams(lp);
//         listView.setPadding(0, originalPaddingTop, 0, 0);
//
//         headerLp.bottomMargin = originalHeaderBottomMargin;
//         header.setLayoutParams(headerLp);
//
//         rootContent.requestLayout();
//     }

    private void savePdfToDownloads(PdfDocument pdfDocument) {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, "Caving_Tour_Full_Report.pdf");
        values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

        try {
            ContentResolver resolver = getContentResolver();
            Uri uri = null;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            }
            if (uri != null) {
                OutputStream out = resolver.openOutputStream(uri);
                pdfDocument.writeTo(out);
                out.close();
                Toast.makeText(this, "PDF saved!", Toast.LENGTH_SHORT).show();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            pdfDocument.close();
        }
    }

//    private Bitmap compressBitmap(Bitmap original) {
//        ByteArrayOutputStream out = new ByteArrayOutputStream();
//  /// Quality will be set to 50% !!!!
//        original.compress(Bitmap.CompressFormat.JPEG, 50, out);
//        byte[] byteArray = out.toByteArray();
//        return BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
//    }

    private Bitmap compressBitmap(Bitmap original) {
        // 1. SKALIERUNG: Verkleinere das Bild auf eine vernünftige max. Breite
        int maxWidth = 1200;
        Bitmap scaled;
        if (original.getWidth() > maxWidth) {
            float aspect = (float) original.getHeight() / (float) original.getWidth();
            scaled = Bitmap.createScaledBitmap(original, maxWidth, (int)(maxWidth * aspect), true);
        } else {
            scaled = original;
        }

        // 2. QUALITÄT: Komprimiere auf JPEG
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        scaled.compress(Bitmap.CompressFormat.JPEG, 25, out);
        byte[] byteArray = out.toByteArray();

        Bitmap result = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);

        // WICHTIG: Speicher freigeben, wenn das Original nicht mehr gebraucht wird
        if (scaled != original) scaled.recycle();

        return result;
    }
}





