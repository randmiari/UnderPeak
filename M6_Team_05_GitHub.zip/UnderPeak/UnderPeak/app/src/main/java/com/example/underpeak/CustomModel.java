package com.example.underpeak;

public class CustomModel {

    private int image;

    private String title;
    private String location;     // e.g. "Streitberg, 25 km"
    private String ratingText;   // e.g. "4.8 (324 reviews)"
    private String difficulty;   // e.g. "Moderate"

    private int distanceMiles;   // e.g. 25
    private int depthMeters;     // e.g. 95

    private String caveType;     // e.g. "Dolomite"
    private String[] features;   // e.g. {"Stalactiten", ...}
    private String about;        // big description

    public CustomModel(
            int image,
            String title,
            String location,
            String ratingText,
            String difficulty,
            int distanceMiles,
            int depthMeters,
            String caveType,
            String[] features,
            String about
    ) {
        this.image = image;
        this.title = title;
        this.location = location;
        this.ratingText = ratingText;
        this.difficulty = difficulty;
        this.distanceMiles = distanceMiles;
        this.depthMeters = depthMeters;
        this.caveType = caveType;
        this.features = features;
        this.about = about;
    }


    //Getter used by Adapter and DetailsActivity
    public int getImage() { return image; }
    public String getTitle() { return title; }
    public String getLocation() { return location; }
    public String getRatingText() { return ratingText; }
    public String getDifficulty() { return difficulty; }

    public int getDistanceMiles() { return distanceMiles; }
    public int getDepthMeters() { return depthMeters; }

    public String getCaveType() { return caveType; }
    public String[] getFeatures() { return features; }
    public String getAbout() { return about; }
}
