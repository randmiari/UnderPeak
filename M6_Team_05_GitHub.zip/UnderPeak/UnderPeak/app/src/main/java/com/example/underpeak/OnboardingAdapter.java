package com.example.underpeak;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class OnboardingAdapter extends RecyclerView.Adapter<OnboardingAdapter.ViewHolder> {

    private final String[] titles;
    private final String[] descriptions;

    // Stores which page is currently selected
    private int currentPage = 0;

    public OnboardingAdapter(String[] titles, String[] descriptions) {
        this.titles = titles;
        this.descriptions = descriptions;
    }

    // Called from MainActivity when page changes
    public void setCurrentPage(int page) {
        currentPage = page;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_onboarding, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.txtTitle.setText(titles[position]);
        holder.txtDesc.setText(descriptions[position]);

        // Create dots then highlight the active dot
        holder.setupDots(titles.length);
        holder.setActiveDot(currentPage);
    }

    @Override
    public int getItemCount() {
        return titles.length;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtTitle, txtDesc;
        LinearLayout dotsLayout;

        ViewHolder(@NonNull View itemView) {
            super(itemView);

            txtTitle = itemView.findViewById(R.id.txtTitle);
            txtDesc = itemView.findViewById(R.id.txtDesc);
            dotsLayout = itemView.findViewById(R.id.dotsLayout);
        }

        void setupDots(int count) {
            dotsLayout.removeAllViews();

            for (int i = 0; i < count; i++) {
                ImageView dot = new ImageView(itemView.getContext());

                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

                params.setMargins(10, 0, 10, 0);
                dot.setLayoutParams(params);

                dot.setImageResource(R.drawable.dot_inactive);
                dotsLayout.addView(dot);
            }
        }

        void setActiveDot(int index) {
            for (int i = 0; i < dotsLayout.getChildCount(); i++) {
                ImageView dot = (ImageView) dotsLayout.getChildAt(i);
                dot.setImageResource(i == index ? R.drawable.dot_active : R.drawable.dot_inactive);
            }
        }
    }
}
