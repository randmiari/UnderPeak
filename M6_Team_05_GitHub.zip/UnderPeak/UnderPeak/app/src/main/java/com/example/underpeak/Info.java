package com.example.underpeak;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Info extends Fragment {

    private RecyclerView rvGuide;
    private BeginnerGuideAdapter adapter;

    public Info() {

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // 1. Inflate the layout (make sure it has the RecyclerView inside)
        View view = inflater.inflate(R.layout.fragment_info, container, false);

        // 2. Initialize the RecyclerView
        rvGuide = view.findViewById(R.id.rvGuide); // Ensure this ID matches fragment_info.xml

        // 3. Set the LayoutManager (Vertical list)
        rvGuide.setLayoutManager(new LinearLayoutManager(requireContext()));

        // 4. Get the data from the AppData class
        List<BeginnerCardItem> guideData = AppData.getBeginnerGuideItems();

        // 5. Initialize and set the Adapter
        adapter = new BeginnerGuideAdapter(guideData);
        rvGuide.setAdapter(adapter);

        return view;
    }
}