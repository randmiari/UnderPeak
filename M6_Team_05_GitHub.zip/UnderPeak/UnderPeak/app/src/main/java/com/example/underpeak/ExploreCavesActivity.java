package com.example.underpeak;

import android.os.Bundle;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class ExploreCavesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exploring_details);

        ImageButton btnBack = findViewById(R.id.btnClose);
        btnBack.setOnClickListener(v -> onBackPressed());
    }
}
