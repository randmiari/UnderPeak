package com.example.underpeak;

import static androidx.core.content.ContentProviderCompat.requireContext;

import static java.security.AccessController.getContext;

import android.Manifest;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CavingActivity extends AppCompatActivity {

    private Button EndButton;
    private long startTime = Long.MAX_VALUE;
    private boolean returnInitiated = false;
    private boolean headToInitiated = true;
    private boolean ended = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_caving);
        //ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
        //    Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
        //    v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
        //    return insets;


        /// HERE IS HOW EVERYTHING WORKS:
//
//        AlertDialog dialog = new AlertDialog.Builder(JourneyOverviewActivity.this, R.style.myTheme)
//                .setTitle("Editing your journey-timeline")
//                .setMessage("By clicking on the text of a timeline entry you can edit its text.")
//                .setMessage("Press and hold an item to delete it.")
//                .setPositiveButton("Okay", (d, which) -> d.dismiss())
//                .create();
//        dialog.show();


        if (startTime != -1) {
            getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
                @Override
                public void handleOnBackPressed() {
                    //"going back" should be now deactivated
                }
            });
        } ///END




        /// HERE IS THE "END CAVE TOUR BUTTON"!!!////
        getSupportFragmentManager() /// GETTING THE START_TIME OF THE CAVETOUR
                .setFragmentResultListener(
                        "setFlagTime",
                        this,
                        (key, bundle) -> {
                            startTime = bundle.getLong("startTime");
                        }
                ); ///END

        EndButton = findViewById(R.id.end_buttonID);
        EndButton.setOnClickListener(v -> {
            new AlertDialog.Builder(CavingActivity.this, R.style.myTheme)
                    .setTitle("END THIS TOUR")
                    .setMessage("Do you really want to end this caving-tour?")
                    .setPositiveButton("Yes", (dialog1, which) -> {

                        setEnded(true);
                        Intent intent = new Intent(CavingActivity.this, JourneyOverviewActivity.class);
                        intent.putExtra("START_TIME", startTime); //Sending the start_time to the other activity
                        startActivity(intent);
                    })
                    .setNegativeButton("No", (dialog1, which) -> {
                        dialog1.dismiss();
                    })
                    .show();

        });
        /// End of the END CAVE TOUR BUTTON


    //NEWER VERSIONS OF ANDROID REQUIRE A "BENACHRICHTIGUNS_ERLAUBNIS" THIS IS WHAT ATLEAST IS SUPPOSED TO HAPPEN HERE
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        100
                );
            }
        }


        //THIS IS SOME PATCHWORK CODE MADE BY COMBINATION OF A FEW THINGS I FOUND ON THE INTERNET - IT SHOULD MAKE SURE THAT CHANNELS ARE USED IF THE ANDROID-VERSION REQUIRES A
        //ALSO IT SHOULD MAKE THE SOUND_OUTPUT FOR THE NOTIFICATION...
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Uri soundUri = Uri.parse("android.resource://" +
                    getPackageName() + "/raw/ringtone");

            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();

            NotificationChannel channel = new NotificationChannel("channel_ID2", "channel", NotificationManager.IMPORTANCE_HIGH);
            channel.setSound(soundUri, audioAttributes);

            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }





    //HERE IS THE "ADDING_OF_FRAGMENTS INTO CAVING ACTIVITY!!!
        getSupportFragmentManager()
                    .beginTransaction()

                    .add(R.id.fragment_caveMapID, new CaveMapFragment())
                   .add(R.id.fragment_timerID, new TimerFragment())
                    .commit();
    }

//    /// MESSAGE WHEN U CLICK ON HOME BUTTON!!!!
//    @Override
//    protected void onUserLeaveHint() {
//        super.onUserLeaveHint();
//        sendReturnWarningNotification();
//    }
//    /// END

    public void setReturnInitiated() {
        returnInitiated = true;
    }

    public boolean getReturnInitiated() {
        return returnInitiated;
    }


  public void setHeadToInitiated() {
      if(headToInitiated == true) headToInitiated = false;
      else headToInitiated = true;
  }

    public boolean getHeadToIntitiated() {
        return headToInitiated;
    }
    public void setEnded(boolean bool) {
        ended = bool;
    }
    public boolean getEnded() {
        return ended;
    }

    private void sendReturnWarningNotification() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "channel_id")
                .setSmallIcon(R.drawable.checkpointicon_message)
                .setContentTitle("Your tour is still active!")
                .setContentText("Please don't close this app entirely so that the time can continue ticking in the background")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        NotificationManagerCompat manager = NotificationManagerCompat.from(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        manager.notify(99, builder.build()); //I don't get why this never works... its strange?!!?!?!
    }
}
