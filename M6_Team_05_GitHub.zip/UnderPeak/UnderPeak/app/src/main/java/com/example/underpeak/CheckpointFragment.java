package com.example.underpeak;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Objects;


public class CheckpointFragment extends Fragment {

    private static final String TITLE = "title";
    private static final String TEXT = "text";
    private static final String IMAGE = "image";
    private static String checkpointCode = "code";

    public Button button_reachedCheckpoint;

    public static CheckpointFragment newInstance(String title, String text, int imageResId) {
        CheckpointFragment fragment = new CheckpointFragment();
        Bundle args = new Bundle();
        args.putString(TITLE, title);
        args.putString(TEXT, text);
        args.putInt(IMAGE, imageResId);
        fragment.setArguments(args);
        return fragment;
    }

    public CheckpointFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_checkpoint, container, false);

        TextView title = view.findViewById(R.id.title_checkpointID);
        TextView text = view.findViewById(R.id.text_checkpointID);
        ImageView image = view.findViewById(R.id.image_checkpointID);

        if (getArguments() != null) {
            title.setText(getArguments().getString(TITLE));
            text.setText(getArguments().getString(TEXT));
            image.setImageResource(getArguments().getInt(IMAGE));
            checkpointCode = getArguments().getString(TITLE);
        }

        //IF YOU CLICK ON THE REACHED_BUTTON...
        button_reachedCheckpoint = view.findViewById(R.id.button_startCheckpointID);
        if ("Take your time to check out every corner - after that you can select a new checkpoint to explore".equals(getArguments().getString(TEXT)) || "Cave Entrance".equals(getArguments().getString(TITLE)) || ((CavingActivity) requireActivity()).getReturnInitiated() || ((CavingActivity) requireActivity()).getHeadToIntitiated()) button_reachedCheckpoint.setVisibility(View.GONE);
        button_reachedCheckpoint.setOnClickListener(v -> {


            ///SENDING MESSAGE TO TIMER_FRAGMENT
            Bundle bundle = new Bundle();
            bundle.putString("flag", checkpointCode);

            getParentFragmentManager().setFragmentResult("setFlag", bundle);
                    button_reachedCheckpoint.setVisibility(View.GONE);
            //TO DO: NICE TO HAVE: CONFIRM, THAT U HAVE REACHED THIS CHECKPOINT!
        });




        //IF YOU CLICK ON THE IMAGE IN CHECKPOINTS THE DETAIL-VIEW OPENS UP!!!
        image.setOnClickListener(v -> {
           // Toast.makeText(getContext(), "this fucking works!!!", Toast.LENGTH_SHORT).show();

            int imageInt = getArguments().getInt(IMAGE);

            Intent intent = new Intent(requireContext(), ImageDetailZOOMABLEActivity.class);
            intent.putExtra(ImageDetailZOOMABLEActivity.detail_image, imageInt);
            startActivity(intent);
        });


        return view;
    }

}
