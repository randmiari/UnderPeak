package com.example.underpeak;
import static androidx.core.content.ContentProviderCompat.requireContext;

import com.example.underpeak.ImageRepository;
import com.example.underpeak.CapturedImage;


import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.io.File;

@SuppressLint("SuspiciousIndentation")
public class CameraActivity extends AppCompatActivity {

    private PreviewView previewView;
    private ImageCapture imageCapture;
    private String currentCheckpoint;
    private View blackFlash;

    private int cameraPermissionFirstEnabled;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        EdgeToEdge.enable(this);
        super.onCreate(savedInstanceState);
        currentCheckpoint =  getIntent().getStringExtra("CHECKPOINT");
        setContentView(R.layout.activity_camera);

        blackFlash = findViewById(R.id.blackFlashID);


        /// /WONT STAY HERE!!!!!!!!! GOES INTO CAVING ACTIVITY EVENTUALLY!!!!
        Button TimeLineButton = findViewById(R.id.timeline_ButtonID);
        TimeLineButton.setOnClickListener(v -> {
                    // Toast.makeText(getContext(), "this fucking works!!!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(CameraActivity.this, JourneyOverviewActivity.class);
                    startActivity(intent);
                });
        /////////////////ENDS HERE!!!!!!

        previewView = findViewById(R.id.previewView);
        ImageButton captureButton = findViewById(R.id.captureButtonID);

        if (allPermissionsGranted()) {
            startCamera();
        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.CAMERA},
                    10
            );
            startCamera();
        }

        captureButton.setOnClickListener(v -> takePhoto());
    }

    private boolean allPermissionsGranted() {
        return ContextCompat.checkSelfPermission(
                this, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED;
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture =
                ProcessCameraProvider.getInstance(this);

        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider =
                        cameraProviderFuture.get();

                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());

                imageCapture = new ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                        .build();

                CameraSelector cameraSelector =
                        CameraSelector.DEFAULT_BACK_CAMERA;

                cameraProvider.unbindAll();
                cameraProvider.bindToLifecycle(
                        this,
                        cameraSelector,
                        preview,
                        imageCapture
                );

            } catch (Exception e) {
                e.printStackTrace();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    @SuppressLint("SuspiciousIndentation")
    private void takePhoto() {
        if (imageCapture == null) return;

            /// BLACK FLASH FOR PHOTO!!!
            blackFlash.setVisibility(View.VISIBLE);
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                blackFlash.setVisibility(View.GONE);
            }, 100);
            /// END

        //  if (cameraPermissionFirstEnabled == 0)  if (allPermissionsGranted()) {startCamera(); cameraPermissionFirstEnabled = 1;}

        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME,
                "cave_" + System.currentTimeMillis());
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH,
                Environment.DIRECTORY_PICTURES + "/CaveApp");

        ImageCapture.OutputFileOptions options =
                new ImageCapture.OutputFileOptions.Builder(
                        getContentResolver(),
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        values
                ).build();

        imageCapture.takePicture(
                options,
                ContextCompat.getMainExecutor(this),
                new ImageCapture.OnImageSavedCallback() {

                    public void onImageSaved(
                            @NonNull ImageCapture.OutputFileResults output) {

                        Uri savedUri = output.getSavedUri();

                        if (savedUri != null) {
                            ImageRepository.addImage(
                                    new CapturedImage(
                                            savedUri.toString(),
                                            System.currentTimeMillis(),
                                            currentCheckpoint
                                    )
                            );
                        }

                    }


                    @Override
                    public void onError(
                            @NonNull ImageCaptureException exc) {
                        exc.printStackTrace();
                    }
                }


        );


    }

}
