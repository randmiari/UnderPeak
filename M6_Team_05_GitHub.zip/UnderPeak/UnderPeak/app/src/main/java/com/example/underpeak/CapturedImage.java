package com.example.underpeak;


/// This method is my datamodel in order to save the images taken inside of the app.
/// This is a Entity that represents each Picture for my model

public class CapturedImage {

    private final String uri;
    private final long timeOfTaking;
    private final String checkpoint;

    public CapturedImage(String uri, long timestamp, String checkpoint) {
        this.uri = uri;
        this.timeOfTaking = timestamp;
        this.checkpoint = checkpoint;
    }

    public String getUri() {
        return uri;
    }

    public long getTime() {
        return timeOfTaking;
    }

    public String getCheckpoint() {
        return checkpoint;
    }
}
