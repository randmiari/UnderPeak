package com.example.underpeak;



import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class BeginnerGuideAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final List<BeginnerCardItem> items;

    public BeginnerGuideAdapter(List<BeginnerCardItem> items) {
        this.items = items;
    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position).type;
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inf = LayoutInflater.from(parent.getContext());

        if (viewType == BeginnerCardItem.TYPE_HERO) {
            return new HeroVH(inf.inflate(R.layout.item_guide_hero, parent, false));
        } else if (viewType == BeginnerCardItem.TYPE_SECTION) {
            return new SectionVH(inf.inflate(R.layout.item_guide_section, parent, false));
        } else if (viewType == BeginnerCardItem.TYPE_IMAGE) {
            return new ImageVH(inf.inflate(R.layout.item_guide_card_image, parent, false));
        } else if (viewType == BeginnerCardItem.TYPE_BULLETS) {
            return new BulletsVH(inf.inflate(R.layout.item_guide_card_bullets, parent, false));
        } else if (viewType == BeginnerCardItem.TYPE_NUMBERED) {
            return new NumberVH(inf.inflate(R.layout.item_guide_card_numbered, parent, false));
        } else if (viewType == BeginnerCardItem.TYPE_PARAGRAPH) {
            return new ParagraphVH(inf.inflate(R.layout.item_guide_paragraph, parent, false));
        } else {
            return new SimpleVH(inf.inflate(R.layout.item_guide_card_simple, parent, false));
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        BeginnerCardItem it = items.get(position);

        if (holder instanceof HeroVH) {
            HeroVH vh = (HeroVH) holder;
            vh.ivHero.setImageResource(it.imageRes);
            vh.tvTitle.setText(it.title);
            vh.tvSub.setText(it.subtitle);

        } else if (holder instanceof SectionVH) {
            SectionVH vh = (SectionVH) holder;
            vh.ivIcon.setImageResource(it.iconRes);
            vh.tvTitle.setText(it.title);

        } else if (holder instanceof SimpleVH) {
            SimpleVH vh = (SimpleVH) holder;
            vh.tvTitle.setText(it.title);
            vh.tvText.setText(it.text);

        } else if (holder instanceof ImageVH) {
            ImageVH vh = (ImageVH) holder;
            vh.ivImage.setImageResource(it.imageRes);
            vh.tvTitle.setText(it.title);
            vh.tvText.setText(it.text);

        } else if (holder instanceof BulletsVH) {
            BulletsVH vh = (BulletsVH) holder;
            vh.tvTitle.setText(it.title);

            // Build bullet text
            StringBuilder sb = new StringBuilder();
            if (it.bullets != null) {
                for (String b : it.bullets) {
                    sb.append("• ").append(b).append("\n");
                }
            }
            vh.tvBullets.setText(sb.toString().trim());

        } else if (holder instanceof NumberVH) {
            NumberVH vh = (NumberVH) holder;
            vh.tvNumber.setText(String.valueOf(it.number));
            vh.tvTitle.setText(it.title);
            vh.tvText.setText(it.text);

        } else if (holder instanceof ParagraphVH) {
            ParagraphVH vh = (ParagraphVH) holder;
            vh.tvParagraph.setText(it.text);
        }
    }

    // ---------- ViewHolders ----------

    static class HeroVH extends RecyclerView.ViewHolder {
        ImageView ivHero;
        TextView tvTitle, tvSub;
        HeroVH(@NonNull View itemView) {
            super(itemView);
            ivHero = itemView.findViewById(R.id.ivHero);
            tvTitle = itemView.findViewById(R.id.tvHeroTitle);
            tvSub = itemView.findViewById(R.id.tvHeroSub);
        }
    }

    static class SectionVH extends RecyclerView.ViewHolder {
        ImageView ivIcon;
        TextView tvTitle;
        SectionVH(@NonNull View itemView) {
            super(itemView);
            ivIcon = itemView.findViewById(R.id.ivSectionIcon);
            tvTitle = itemView.findViewById(R.id.tvSectionTitle);
        }
    }

    static class SimpleVH extends RecyclerView.ViewHolder {
        TextView tvTitle, tvText;
        SimpleVH(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvText = itemView.findViewById(R.id.tvText);
        }
    }

    static class ImageVH extends RecyclerView.ViewHolder {
        ImageView ivImage;
        TextView tvTitle, tvText;
        ImageVH(@NonNull View itemView) {
            super(itemView);
            ivImage = itemView.findViewById(R.id.ivImage);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvText = itemView.findViewById(R.id.tvText);
        }
    }

    static class BulletsVH extends RecyclerView.ViewHolder {
        TextView tvTitle, tvBullets;
        BulletsVH(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvBullets = itemView.findViewById(R.id.tvBullets);
        }
    }

    static class NumberVH extends RecyclerView.ViewHolder {
        TextView tvNumber, tvTitle, tvText;
        NumberVH(@NonNull View itemView) {
            super(itemView);
            tvNumber = itemView.findViewById(R.id.tvNumber);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvText = itemView.findViewById(R.id.tvText);
        }
    }

    static class ParagraphVH extends RecyclerView.ViewHolder {
        TextView tvParagraph;
        ParagraphVH(@NonNull View itemView) {
            super(itemView);
            tvParagraph = itemView.findViewById(R.id.tvParagraph);
        }
    }
}
