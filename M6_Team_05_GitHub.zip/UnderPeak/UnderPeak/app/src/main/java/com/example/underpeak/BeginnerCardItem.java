package com.example.underpeak;


/**
 * Beginner guide supports different card types.
 * This is a "multi-type item" model.
 */
public class BeginnerCardItem {

    public static final int TYPE_HERO = 1;
    public static final int TYPE_SECTION = 2;
    public static final int TYPE_SIMPLE = 3;
    public static final int TYPE_IMAGE = 4;
    public static final int TYPE_BULLETS = 5;
    public static final int TYPE_NUMBERED = 6;
    public static final int TYPE_PARAGRAPH = 7;

    public final int type;

    // shared
    public String title;
    public String subtitle;
    public String text;

    // images/icons
    public int imageRes;
    public int iconRes;

    // bullets
    public String[] bullets;

    // numbered
    public int number;

    private BeginnerCardItem(int type) { this.type = type; }

    public static BeginnerCardItem hero(int imageRes, String title, String subtitle) {
        BeginnerCardItem i = new BeginnerCardItem(TYPE_HERO);
        i.imageRes = imageRes;
        i.title = title;
        i.subtitle = subtitle;
        return i;
    }

    public static BeginnerCardItem paragraph(String text) {
        BeginnerCardItem i = new BeginnerCardItem(TYPE_PARAGRAPH);
        i.text = text;
        return i;
    }

    public static BeginnerCardItem section(String title, int iconRes) {
        BeginnerCardItem i = new BeginnerCardItem(TYPE_SECTION);
        i.title = title;
        i.iconRes = iconRes;
        return i;
    }

    public static BeginnerCardItem simpleCard(String title, String text) {
        BeginnerCardItem i = new BeginnerCardItem(TYPE_SIMPLE);
        i.title = title;
        i.text = text;
        return i;
    }

    public static BeginnerCardItem imageCard(int imageRes, String title, String text) {
        BeginnerCardItem i = new BeginnerCardItem(TYPE_IMAGE);
        i.imageRes = imageRes;
        i.title = title;
        i.text = text;
        return i;
    }

    public static BeginnerCardItem bulletCard(String title, String[] bullets) {
        BeginnerCardItem i = new BeginnerCardItem(TYPE_BULLETS);
        i.title = title;
        i.bullets = bullets;
        return i;
    }

    public static BeginnerCardItem numberedCard(int number, String title, String text) {
        BeginnerCardItem i = new BeginnerCardItem(TYPE_NUMBERED);
        i.number = number;
        i.title = title;
        i.text = text;
        return i;
    }
}
