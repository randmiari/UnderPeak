package com.example.underpeak;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import android.app.Dialog;

public class CaveDetailsActivity extends AppCompatActivity {

    // Keys for receiving data
    public static final String EXTRA_IMAGE = "extra_image";
    public static final String EXTRA_TITLE = "extra_title";
    public static final String EXTRA_LOCATION = "extra_location";
    public static final String EXTRA_RATING = "extra_rating";
    public static final String EXTRA_DIFFICULTY = "extra_difficulty";
    public static final String EXTRA_DISTANCE = "extra_distance";
    public static final String EXTRA_DEPTH = "extra_depth";
    public static final String EXTRA_CAVE_TYPE = "extra_cave_type";
    public static final String EXTRA_FEATURES = "extra_features";
    public static final String EXTRA_ABOUT = "extra_about";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cave_details);

        // 1. Initialize UI Elements
        ImageView detailImage = findViewById(R.id.detailImage);
        ImageButton btnClose = findViewById(R.id.btnClose);
        TextView detailTitle = findViewById(R.id.detailTitle);
        TextView badge = findViewById(R.id.detailDifficultyBadge);
        TextView detailLocation = findViewById(R.id.detailLocation);
        TextView statDistanceLine = findViewById(R.id.statDistanceLine);
        TextView statRatingText = findViewById(R.id.statRatingText);
        TextView statDepthLine = findViewById(R.id.statDepthLine);
        TextView caveTypeChip = findViewById(R.id.caveTypeChip);
        ChipGroup chipGroupFeatures = findViewById(R.id.chipGroupFeatures);
        TextView detailAbout = findViewById(R.id.detailAbout);
        MaterialButton btnDirections = findViewById(R.id.btnDirections);
        MaterialButton btnSave = findViewById(R.id.btnSave);
        MaterialButton btnTimer = findViewById(R.id.btnTimer);

        // 2. Get Data from Intent
        Intent i = getIntent();
        int img = i.getIntExtra(EXTRA_IMAGE, 0);
        String title = i.getStringExtra(EXTRA_TITLE);
        String location = i.getStringExtra(EXTRA_LOCATION);
        String rating = i.getStringExtra(EXTRA_RATING);
        String difficulty = i.getStringExtra(EXTRA_DIFFICULTY);
        int distance = i.getIntExtra(EXTRA_DISTANCE, 0);
        int depth = i.getIntExtra(EXTRA_DEPTH, 0);
        String caveType = i.getStringExtra(EXTRA_CAVE_TYPE);
        String[] features = i.getStringArrayExtra(EXTRA_FEATURES);
        String about = i.getStringExtra(EXTRA_ABOUT);

        // 3. Populate Views with Data
        if (img != 0) detailImage.setImageResource(img);

        detailTitle.setText(title != null ? title : "Unknown Cave");
        badge.setText(difficulty);
        detailLocation.setText(location);
        statDistanceLine.setText(distance + " miles");
        statRatingText.setText(rating);
        statDepthLine.setText(depth + " meters");
        caveTypeChip.setText(caveType);
        detailAbout.setText(about);

        // 4. Revised Chip Logic (Feature Tags)
        chipGroupFeatures.removeAllViews();
        if (features != null && features.length > 0) {
            for (String f : features) {
                Chip chip = new Chip(this);
                chip.setText(f);
                chip.setClickable(false);
                chip.setCheckable(false);
                chip.setTextSize(12);

                // Background and Stroke
                chip.setChipBackgroundColorResource(android.R.color.white);
                chip.setChipStrokeWidth(2f);
                chip.setChipStrokeColorResource(android.R.color.black);
                chip.setChipCornerRadius(999f);

                // Text Color - This is what was missing
                chip.setTextColor(getResources().getColor(android.R.color.black, getTheme()));

                chipGroupFeatures.addView(chip);
            }
        }

        // 5. Button Listeners
        btnClose.setOnClickListener(v -> finish());

        btnSave.setOnClickListener(v ->
                Toast.makeText(this, "Saved " + title + " for later!", Toast.LENGTH_SHORT).show()
        );

        btnDirections.setOnClickListener(v -> {
            Uri uri = Uri.parse("geo:0,0?q=" + Uri.encode(location + " " + title));
            Intent mapIntent = new Intent(Intent.ACTION_VIEW, uri);
            if (mapIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(mapIntent);
            } else {
                Toast.makeText(this, "Maps app not found", Toast.LENGTH_SHORT).show();
            }
        });

        // --- TIMER BUTTON LOGIC ---
        btnTimer.setOnClickListener(v -> {
            Intent timerIntent = new Intent(CaveDetailsActivity.this, CavingActivity.class);
            // Pass the cave name to the next activity
            timerIntent.putExtra("CAVE_NAME", title);
            startActivity(timerIntent);
        });

        detailImage.setOnClickListener(v -> {
            // 1. Create the full-screen dialog
            Dialog dialog = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);

            // 2. Use PhotoView instead of ImageView
            com.github.chrisbanes.photoview.PhotoView photoView = new com.github.chrisbanes.photoview.PhotoView(this);
            photoView.setImageResource(img); // 'img' is the resource ID
            photoView.setBackgroundColor(android.graphics.Color.BLACK);

            // 3. Set the content
            dialog.setContentView(photoView);

            // If you want to close it with a single tap (careful, this might conflict with zoom)
            // Most users prefer using the 'Back' button to exit full-screen images.

            dialog.show();
        });

    }
}