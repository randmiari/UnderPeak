package com.example.underpeak;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Matrix;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.otaliastudios.zoom.ZoomEngine;
import com.otaliastudios.zoom.ZoomLayout;

public class CaveMapFragment extends Fragment {

     public Button buttonHideMap;
     public Button buttonShowMap;

     public int deactivateButtonZoomReappearence = 0;

     public ImageView imageMap;
    // public ImageView backgroundMap;
    public ImageButton lastClickedButton;
     public ImageButton buttonBridge;
     public ImageButton buttonNarrow;
     public ImageButton buttonSalz;
     public ImageButton buttonPoldi;
     public ImageButton buttonCross;

    public ImageButton buttonEntrance;


    public ImageButton buttonParadis;

    public String checkpointCode = "0";
    public String TextEntrance;
    public String HeadEntrance;


     /// READ ME!!!!!!!!!!!!!!!!
     /// IF U ADD NEW CHECKPOINT_BUTTONS then you have to keep in mind that here u have to
     /// 1. Add the text that is sent to the checkpointFragment!!!
     /// 2. Add the zoom-inside-Hide stuff at the end of this code!!!
     /// 3. Add the Button in "HideMap" !!!


        @Nullable
        @Override
        public View onCreateView(@NonNull LayoutInflater inflater,
                                 @Nullable ViewGroup container,
                                 @Nullable Bundle savedInstanceState) {



            View view = inflater.inflate(R.layout.fragment_cave_map, container, false);
            ZoomLayout zoomLayout = view.findViewById(R.id.fragment_caveMapID);

            ///Min und Max zoom können hier gesetzt werden
            zoomLayout.setMinZoom(1f);
            zoomLayout.setMaxZoom(6f);
            zoomLayout.setTransformation(ZoomLayout.TRANSFORMATION_CENTER_INSIDE);


            /// HERE IS CODED HOW TO MAKE THE MAP DISAPPEAR AND REAPPEAR! THIS INCLUDES Making buttons invisible, making them visible again,
            /// stopping the reappearing of buttons due to the zooming/dragging - also deactivating and reactivating zooming
            buttonHideMap = view.findViewById(R.id.button_HideMapID);
            buttonShowMap = view.findViewById(R.id.button_ShowMapID);
            imageMap = view.findViewById(R.id.C9mapID);
            //backgroundMap = view.findViewById(R.id.backgroundMapID);
            View container2 = requireActivity().findViewById(R.id.fragment_caveMapID);
            ViewGroup.LayoutParams params = container2.getLayoutParams(); //Gibt mir wohl die Layout-parameter meines Views oder so...

            if (deactivateButtonZoomReappearence == 0) {
                buttonShowMap.setVisibility(View.GONE);
                //backgroundMap.setVisibility(View.GONE);
            }

            buttonHideMap.setOnClickListener(v -> {

                    buttonBridge.setVisibility(View.GONE);
                    buttonNarrow.setVisibility(View.GONE);
                    buttonCross.setVisibility(View.GONE);
                    buttonParadis.setVisibility(View.GONE);
                    buttonSalz.setVisibility(View.GONE);
                    buttonPoldi.setVisibility(View.GONE);
                    buttonEntrance.setVisibility(View.GONE);
                    //ADD FURTHER BUTTONS HERE IF MADE!!!

                    imageMap.setVisibility(View.INVISIBLE);
                    deactivateButtonZoomReappearence = 1;
                    buttonHideMap.setVisibility(View.INVISIBLE);
                    buttonShowMap.setVisibility(View.VISIBLE);
                   // backgroundMap.setVisibility(View.VISIBLE);

                /// THIS IS FOR MAKING THE FRAGMENT SMALLER ONCE THE MAP DISAPPEARS!!
                    params.height = dpToPx(100);
                    container2.setLayoutParams(params);


                    zoomLayout.setMinZoom(1f);
                    zoomLayout.setMaxZoom(1f);
                    zoomLayout.setHorizontalPanEnabled(false);
                    zoomLayout.setVerticalPanEnabled(false);

            });

            buttonShowMap.setOnClickListener(v -> {


                    buttonBridge.setVisibility(View.VISIBLE);
                    buttonNarrow.setVisibility(View.VISIBLE);
                    buttonCross.setVisibility(View.VISIBLE);
                    buttonParadis.setVisibility(View.VISIBLE);
                    buttonSalz.setVisibility(View.VISIBLE);
                    buttonPoldi.setVisibility(View.VISIBLE);
                    buttonEntrance.setVisibility(View.VISIBLE);
                    //ADD FURTHER BUTTONS HERE IF MADE!!!

                    imageMap.setVisibility(View.VISIBLE);
                    deactivateButtonZoomReappearence = 0;
                    buttonHideMap.setVisibility(View.VISIBLE);
                    buttonShowMap.setVisibility(View.GONE);
                //   backgroundMap.setVisibility(View.GONE);

                    params.height = dpToPx(400);
                    container2.setLayoutParams(params);
                    zoomLayout.setHorizontalPanEnabled(true);
                    zoomLayout.setVerticalPanEnabled(true);

                    zoomLayout.setMaxZoom(7f);
                    zoomLayout.setMinZoom(1f);

            });




            ///HERE ARE THE CHECKPOINT_BUTTONS!!!!
            buttonEntrance = view.findViewById(R.id.button_CheckpointEntranceID);

            buttonEntrance.setOnClickListener(v -> {
                if(((CavingActivity) requireActivity()).getReturnInitiated()) {
                    HeadEntrance= "Head to the entrance";
                    TextEntrance ="Your exploration time is over - the remaining time should be used for a save and not rushed return to the entrance";
                }

                else{
                    HeadEntrance= "Cave Entrance";
                    TextEntrance ="This is the cave entrance - this is where the mysterious part of your adventure begins. Please tell your emergency contact that your caving tour is about to happen and press at the \"START CAVE TIMER\"-Button in order for your tour to beginn.";
                }

                CheckpointFragment checkpointFragment =
                        CheckpointFragment.newInstance(
                                HeadEntrance,
                                TextEntrance,
                                R.drawable.caveentrance
                        );

                requireActivity().getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_checkpointTextID, checkpointFragment)
                        .addToBackStack(null)
                        .commit();

            });
            buttonBridge = view.findViewById(R.id.button_checkpointBridgeID);
                buttonBridge.setOnClickListener(v -> {

                                CheckpointFragment checkpointFragment = CheckpointFragment.newInstance(
                                                "Checkpoint: Wooden Bridge",
                                                "This is the first step inside the cave.",
                                                R.drawable.checkpointbruecke
                                        );

                                requireActivity().getSupportFragmentManager()
                                        .beginTransaction()
                                        .replace(R.id.fragment_checkpointTextID, checkpointFragment)
                                        .addToBackStack(null)
                                        .commit();

                });



            buttonNarrow = view.findViewById(R.id.button_checkpointNarrowID);
                buttonNarrow.setOnClickListener(v -> {

                    CheckpointFragment checkpointFragment =
                        CheckpointFragment.newInstance(
                                "Checkpoint: Narrow Passage",
                                "Once you have reached this Checkpoint you will find a narrow squeez infront of you",
                                R.drawable.checkpointnarrowpassage
                        );

                requireActivity().getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_checkpointTextID, checkpointFragment)
                        .addToBackStack(null)
                        .commit();

                });

            buttonSalz = view.findViewById(R.id.button_CheckpointSalzmaennchenID);
            buttonSalz.setOnClickListener(v -> {

                CheckpointFragment checkpointFragment =
                        CheckpointFragment.newInstance(
                                "Checkpoint: Salzmännchen",
                                "Once you have reached this Checkpoint you will find yourself in a larger cavity that has a distinctive stalagmite called 'Salzmännchen'",
                                R.drawable.checkpointsalz
                        );

                requireActivity().getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_checkpointTextID, checkpointFragment)
                        .addToBackStack(null)
                        .commit();

            });

            buttonPoldi = view.findViewById(R.id.button_CheckpointCollumID);
            buttonPoldi.setOnClickListener(v -> {

                CheckpointFragment checkpointFragment =
                        CheckpointFragment.newInstance(
                                "Checkpoint: Gigantic Collum",
                                "Once you have reached this Checkpoint you will be able to see this gigantic collum",
                                R.drawable.poldisaeule
                        );

                requireActivity().getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_checkpointTextID, checkpointFragment)
                        .addToBackStack(null)
                        .commit();

            });


            buttonParadis = view.findViewById(R.id.button_CheckpointParadieshalleID);
            buttonParadis.setOnClickListener(v -> {

                CheckpointFragment checkpointFragment =
                        CheckpointFragment.newInstance(
                                "Checkpoint: Paradisehall",
                                "This is a rather large cavity that can't be mistaken, even if the stalagmites look different from every angle",
                                R.drawable.checkpointparadishalle
                        );

                requireActivity().getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_checkpointTextID, checkpointFragment)
                        .addToBackStack(null)
                        .commit();

            });

            buttonCross = view.findViewById(R.id.button_CrossCrevicesID);
            buttonCross.setOnClickListener(v -> {

                CheckpointFragment checkpointFragment =
                        CheckpointFragment.newInstance(
                                "Checkpoint: Cross-Crevices",
                                "You will find yourself in a high room and no speleothem at all. In order to be sure you have reached the right checkpoint try to find all the entrances into this little hall exactly like drawn on the map",
                                R.drawable.checkpointcross
                        );

                requireActivity().getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_checkpointTextID, checkpointFragment)
                        .addToBackStack(null)
                        .commit();

            });



            ///Wenn stark genug gezoomed wird werden die button_checkpoints auf INVISIBLE gesetzt!!!
            ///MAYBE FOR LATER: FadeIn and FadeOut, see: https://www.tutorialspoint.com/how-to-use-fade-in-and-fade-out-android-animation-in-java
            zoomLayout.getEngine().addListener(new ZoomEngine.Listener() {
            @Override
            public void onIdle(ZoomEngine engine) {}

            @Override
            public void onUpdate(ZoomEngine engine, Matrix matrix) {
            float zoom = engine.getZoom();

            if (zoom > 4f && deactivateButtonZoomReappearence == 0) {
                buttonBridge.setVisibility(View.INVISIBLE);
                buttonNarrow.setVisibility(View.INVISIBLE);
                buttonSalz.setVisibility(View.INVISIBLE);
                buttonPoldi.setVisibility(View.INVISIBLE);
                buttonEntrance.setVisibility(View.INVISIBLE);
                buttonParadis.setVisibility(View.INVISIBLE);
                buttonCross.setVisibility(View.INVISIBLE);
            } else if (deactivateButtonZoomReappearence == 0){
                buttonBridge.setVisibility(View.VISIBLE);
                buttonNarrow.setVisibility(View.VISIBLE);
                buttonSalz.setVisibility(View.VISIBLE);
                buttonPoldi.setVisibility(View.VISIBLE);
                buttonEntrance.setVisibility(View.VISIBLE);
                buttonParadis.setVisibility(View.VISIBLE);
                buttonCross.setVisibility(View.VISIBLE);
            }
        }

            });

     return view;
}

    /// THIS IS A HELPER I HAVE STOLEN :)
    private int dpToPx(int dp) {
        return (int) (dp * requireContext()
                .getResources()
                .getDisplayMetrics()
                .density);
    }

}




