package com.example.underpeak;

public class ImageItemTimeline {

        public String head;
        public String body;
        public String imageUri;

        public ImageItemTimeline(String head, String body, String imageUri) {
            this.head = head;
            this.body = body;
            this.imageUri = imageUri;
            if("0".equals(this.body)) this.body = "At the Entrance";
        }
    }