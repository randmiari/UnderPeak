package com.example.underpeak;
import java.util.ArrayList;

public class ImageRepository {

        private static final ArrayList<CapturedImage> images =
                new ArrayList<>();

        public static void addImage(CapturedImage image) {
            images.add(image);
        }

        public static ArrayList<CapturedImage> getImages() {
            return images;
        }

        public static void clear() {
            images.clear();
        }
    }

