package com.example.underpeak;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class Save extends Fragment {

    private RecyclerView recyclerView;
    private CustomAdapter adapter;
    private TextView tvEmptyState;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_save, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewSaved);
        tvEmptyState = view.findViewById(R.id.tvEmptyState); // A TextView saying "No favorites yet"

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Initialize with an empty list first
        adapter = new CustomAdapter(requireContext(), new ArrayList<>());
        recyclerView.setAdapter(adapter);

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        // Refresh the list every time the user navigates back to this fragment
        loadFavorites();
    }

    private void loadFavorites() {
        // 1. Get ALL caves from the single source of truth
        ArrayList<CustomModel> allCaves = AppData.getAllCaves();
        ArrayList<CustomModel> favoriteCaves = new ArrayList<>();

        // 2. Filter: Only keep caves whose titles are in FavoritesManager
        for (CustomModel cave : allCaves) {
            if (FavoritesManager.isFavorite(requireContext(), cave.getTitle())) {
                favoriteCaves.add(cave);
            }
        }

        // 3. Update the UI
        if (favoriteCaves.isEmpty()) {
            tvEmptyState.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            tvEmptyState.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
            adapter.updateList(favoriteCaves);
        }
    }
}