package com.example.underpeak;

import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

// ViewHolder = holds references to views inside card_item.xml
public class CustomHolder extends RecyclerView.ViewHolder {

    // Made public so CustomAdapter can access them directly
    public View cardRoot;
    public ImageView imageView;
    public TextView title, moderate, location, rating;
    public ImageButton ic_heart;

    public CustomHolder(@NonNull View itemView) {
        super(itemView);

        // Root MaterialCardView
        cardRoot = itemView.findViewById(R.id.cardRoot);

        // Find views based on xml IDs
        imageView = itemView.findViewById(R.id.imageView);
        title = itemView.findViewById(R.id.title);
        moderate = itemView.findViewById(R.id.moderate);
        location = itemView.findViewById(R.id.location);
        rating = itemView.findViewById(R.id.rating);
        ic_heart = itemView.findViewById(R.id.btnSave);
    }
}