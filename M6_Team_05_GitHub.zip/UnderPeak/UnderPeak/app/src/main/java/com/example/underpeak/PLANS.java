

//IMPORTANT: please turn your phone on loud-mode”-reminder
//Adding Button to make the checkpoints disappear!!!
//Confirming one again with "YES" or "NO" when u click on the Reached Checkpoint Button
//Making clicking on notification makes u open up the caveactivity again





/// NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
///
///             if (notificationManager != null && !notificationManager.isNotificationPolicyAccessGranted()) {
///
///                 Intent intent = new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
///
///                 // Den Intent starten (Hinweis: REQUEST_CODE_NOTIFICATION_POLICY muss als int definiert sein)
///                 startActivityForResult(intent, REQUEST_CODE_NOTIFICATION_POLICY);
///             }
///
///
///             if (notificationManager != null && notificationManager.isNotificationPolicyAccessGranted()) {
///
///                 notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
///
///                 if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
///                     // In Java nutzen wir den Konstruktor und die Setter-Methode
///                     NotificationManager.Policy policy = new NotificationManager.Policy(
///                             NotificationManager.Policy.PRIORITY_CATEGORY_ALARMS, 0, 0
///                     );
///
///                     notificationManager.setNotificationPolicy(policy);
///                 }
///             }
///         }