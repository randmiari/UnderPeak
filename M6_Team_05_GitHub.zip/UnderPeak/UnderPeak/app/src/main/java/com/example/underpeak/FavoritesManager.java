package com.example.underpeak;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Set;

public class FavoritesManager {
    private static final String PREF_NAME = "cave_favorites";
    private static final String KEY_LIST = "saved_titles";

    // Adds or Removes a cave title from SharedPreferences
    public static void toggleFavorite(Context context, String title) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        // Important: Create a NEW HashSet to trigger the Preference change listener
        Set<String> favorites = new HashSet<>(prefs.getStringSet(KEY_LIST, new HashSet<>()));

        if (favorites.contains(title)) {
            favorites.remove(title);
        } else {
            favorites.add(title);
        }

        prefs.edit().putStringSet(KEY_LIST, favorites).apply();
    }

    // Checks if a cave is saved (returns true/false)
    public static boolean isFavorite(Context context, String title) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        Set<String> favorites = prefs.getStringSet(KEY_LIST, new HashSet<>());
        return favorites.contains(title);
    }
}