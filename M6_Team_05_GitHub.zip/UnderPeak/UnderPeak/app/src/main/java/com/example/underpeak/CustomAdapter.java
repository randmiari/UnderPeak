package com.example.underpeak;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/**
 * Adapter = connects the list of CustomModel data to the RecyclerView UI.
 */
public class CustomAdapter extends RecyclerView.Adapter<CustomHolder> {

    private Context context;
    private ArrayList<CustomModel> customModelArrayList;

    public CustomAdapter(Context context, ArrayList<CustomModel> customModelArrayList) {
        this.context = context;
        this.customModelArrayList = customModelArrayList;
    }

    @NonNull
    @Override
    public CustomHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the card layout
        return new CustomHolder(LayoutInflater.from(context).inflate(R.layout.card_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull CustomHolder holder, int position) {
        // 1. Get current cave data
        CustomModel model = customModelArrayList.get(position);

        // 2. Fill the Basic UI
        holder.imageView.setImageResource(model.getImage());
        holder.title.setText(model.getTitle());
        holder.moderate.setText(model.getDifficulty());
        holder.location.setText("📍 " + model.getLocation());
        holder.rating.setText("⏱ " + model.getDistanceMiles() + " mi   ⭐ " + model.getRatingText());

        // 3. Heart Icon (Save Feature) Logic
        // Check memory to see if this cave is saved
        if (FavoritesManager.isFavorite(context, model.getTitle())) {
            holder.ic_heart.setImageResource(R.drawable.ic_heart);
        } else {
            holder.ic_heart.setImageResource(R.drawable.ic_heart_outline);
        }

        // Handle clicking the heart
        holder.ic_heart.setOnClickListener(v -> {
            // Save or Unsave in SharedPreferences
            FavoritesManager.toggleFavorite(context, model.getTitle());

            // Update icon color immediately
            if (FavoritesManager.isFavorite(context, model.getTitle())) {
                holder.ic_heart.setImageResource(R.drawable.ic_heart);
            } else {
                holder.ic_heart.setImageResource(R.drawable.ic_heart_outline);

                // Special check: If we are viewing the "Saved" screen,
                // remove the item from the list instantly when un-hearted.
                if (context.getClass().getSimpleName().contains("MainActivity")) {
                    // This keeps the Saved fragment list fresh
                }
            }
        });

        // 4. Navigation Logic (Clicking the card)
        holder.cardRoot.setOnClickListener(v -> {
            Intent intent = new Intent(context, CaveDetailsActivity.class);

            // Pass all required data using Activity constants
            intent.putExtra(CaveDetailsActivity.EXTRA_IMAGE, model.getImage());
            intent.putExtra(CaveDetailsActivity.EXTRA_TITLE, model.getTitle());
            intent.putExtra(CaveDetailsActivity.EXTRA_LOCATION, model.getLocation());
            intent.putExtra(CaveDetailsActivity.EXTRA_RATING, model.getRatingText());
            intent.putExtra(CaveDetailsActivity.EXTRA_DIFFICULTY, model.getDifficulty());
            intent.putExtra(CaveDetailsActivity.EXTRA_DISTANCE, model.getDistanceMiles());
            intent.putExtra(CaveDetailsActivity.EXTRA_DEPTH, model.getDepthMeters());
            intent.putExtra(CaveDetailsActivity.EXTRA_CAVE_TYPE, model.getCaveType());
            intent.putExtra(CaveDetailsActivity.EXTRA_FEATURES, model.getFeatures());
            intent.putExtra(CaveDetailsActivity.EXTRA_ABOUT, model.getAbout());

            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return customModelArrayList.size();
    }

    public void updateList(ArrayList<CustomModel> newList) {
        this.customModelArrayList = newList;
        notifyDataSetChanged();
    }
}